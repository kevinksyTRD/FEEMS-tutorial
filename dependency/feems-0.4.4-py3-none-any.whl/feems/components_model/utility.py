import logging
from enum import unique, Enum
from typing import Optional, cast, Union

import numpy as np
import pandas as pd
from scipy.integrate import trapz, simps
from scipy.interpolate import interp1d, PchipInterpolator


@unique
class IntegrationMethod(Enum):
    simpson = 'simpson'
    trapezoid = 'trapzoid'
    sum_with_time = 'sum_with_time'


def integrate_data_with_regular_time_step(
        *,
        data_to_integrate: np.ndarray,
        time_interval_s: Union[float, np.ndarray] = None,
        integration_method: IntegrationMethod = IntegrationMethod.simpson
) -> float:
    """
    Integrates the data with a regular(constant) time step

    :param data_to_integrate: Data samples to integrate, numpy float array
    :param time_interval_s: Time interval of the data samples in seconds must be a float for simpson or trapezoid,
        and a array for 'sum_with_time'. sum_with_times is the dot product of data_to_integrate and time_interval_s
    :param integration_method: Numerical integration method. Choose among `IntegrationMethod`
    :return: Integrated value
    """
    time_interval_s_is_scalar_number = np.isscalar(time_interval_s) and isinstance(time_interval_s, (float, int))
    if integration_method == IntegrationMethod.simpson:
        assert time_interval_s_is_scalar_number
        return simps(data_to_integrate) * time_interval_s
    elif integration_method == IntegrationMethod.trapezoid:
        assert time_interval_s_is_scalar_number
        return trapz(data_to_integrate) * time_interval_s
    elif integration_method == IntegrationMethod.sum_with_time:
        assert isinstance(time_interval_s, np.ndarray)
        np.testing.assert_array_equal(time_interval_s.shape, data_to_integrate.shape)
        return cast(float, np.dot(data_to_integrate, time_interval_s))
    else:
        msg = 'The given method (%s) for the integration is not valid' % integration_method
        logging.error(msg)
        raise TypeError(msg)


def get_efficiency_curve_from_points(eff_curve: np.ndarray) -> (PchipInterpolator, np.ndarray):
    """
    Returns the efficiency interpolating class object from the points provided
    :param eff_curve: ndarray of shape of (:,2), first column being the percentage load, and the second efficiency,
    can be a single value but should be ndarray with length 1
    :return: UnivariateSpline or interpolate1d class object and sorted eff_curve
    """
    if len(eff_curve) == 1:  # in case of single efficiency value
        curve_points = np.append(np.array([0, 1]).reshape(-1, 1),
                                 np.array([eff_curve[0], eff_curve[0]]).reshape(-1, 1),
                                 axis=1)
        function = interp1d(curve_points[:, 0], curve_points[:, 1], fill_value='extrapolate')
        return function, curve_points
    else:
        eff_curve = eff_curve[eff_curve[:, 0].argsort()]
        return PchipInterpolator(eff_curve[:, 0], eff_curve[:, 1]), eff_curve


def get_efficiency_curve_from_dataframe(
        df: pd.DataFrame, key_word: str = 'efficiency'
) -> (PchipInterpolator, np.ndarray):
    """
    Returns the efficiency interpolating class object from the DataFrame provided
    :param df: DataFrame for the component information
    :param key_word: The keyword for the column names for the efficiency table
    :return: PchipSpline or interpolate1d class object
    """
    #: Find the data for the efficiency
    eff_columns = [s for s in df.columns if key_word in s]

    #: Create a curve_points
    curve_points = np.zeros([len(eff_columns), 2])
    if len(eff_columns) == 1:
        curve_points = np.ravel(df[eff_columns].values)
    else:
        for i, eff_column in enumerate(eff_columns):
            curve_points[i, 0] = float(eff_column[eff_column.find('@') + 1:eff_column.find('%')])
            curve_points[i, 1] = df[eff_column].values[0]
        curve_points = curve_points[curve_points[:, 0].argsort()]
    return get_efficiency_curve_from_points(curve_points)


def get_list_random_distribution_numbers_for_total_number(number_element: int, sum_number: int):
    """
    Returns a list of distributed numbers for a given number of elements and sum of the numbers.
    For each element, the number will be greater than 0.
    :param number_element: A number of element = length of the list ex) 4 should be given for list [a, b, c, d]
    :param total_number: Sum of the numbers of each element ex) a + b + c + d should be given for list [a, b, c, d]
    :return: A list of the numbers of which total sum is equal to sum_number
    """
    assert sum_number >= number_element, "'sum_number can not be smaller than number_element."

    number_of_component_list = np.random.rand(number_element)
    number_of_component_list /= (number_of_component_list.sum() / sum_number)
    number_of_component_list = np.ceil(number_of_component_list).astype(int)
    while number_of_component_list.sum() > sum_number:
        number_of_component_list[np.argmax(number_of_component_list)] -= 1

    return number_of_component_list.tolist()
