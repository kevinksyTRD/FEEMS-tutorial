from typing import Union

import numpy as np
import pandas as pd

from feems.components_model.component_base import Component, BasicComponent
from feems.types_for_feems import (TypeComponent, TypeFuel, TypePower, Speed_rpm, Power_kW)
from feems.components_model.utility import (get_efficiency_curve_from_dataframe, get_efficiency_curve_from_points)


class Engine(Component):
    """
    Engine class for basic information and fuel consumption interpolation
    """

    def __init__(
            self, type_: TypeComponent, name: str = '', rated_power: Power_kW = 0,
            rated_speed: Speed_rpm = 0, bsfc_curve: np.ndarray = None,
            fuel_type: TypeFuel = TypeFuel.HFO,
            file_name: str = None
    ):
        super(Engine, self).__init__(
            name=name, type_=type_, power_type=TypePower.POWER_SOURCE,
            rated_power=rated_power, rated_speed=rated_speed
        )
        self.fuel_type = fuel_type
        if file_name is not None:
            df = pd.read_csv(file_name, index_col=0)
            self.rated_power = df['Rated Power'].values[0]
            self.rated_speed = df['Rated Speed'].values[0]
            self.specific_fuel_consumption_interp, \
            self.specific_fuel_consumption_points = get_efficiency_curve_from_dataframe(df, 'BSFC')
            self.name = df.index[0]
        else:
            self.specific_fuel_consumption_interp, \
            self.specific_fuel_consumption_points = get_efficiency_curve_from_points(bsfc_curve)

    def get_fuel_cons_load_bsfc_from_power_out_kw(self, power: np.ndarray = None) \
            -> (np.ndarray, np.ndarray, np.ndarray):
        """
        Calculate fuel consumption, percentage load and bsfc. If power value is not given, it will
        use the power_output value of the instance.
        :param power: single value or ndarray of power in kW
        :return: fuel consumption (kg/s), load (%), bsfc (g/kWh)
        """
        if power is None:
            power = self.power_output
        load_percent = self.get_load(power)
        bsfc = self.specific_fuel_consumption_interp(load_percent)
        fuel_cons = bsfc * power / 1000 / 3600
        return fuel_cons, load_percent, bsfc


class MainEngineForMechanicalPropulsion(Engine):
    """
    Main engine component class used for mechanical/hybrid propulsion
    """

    def __init__(
            self,
            engine: Engine = None,
            name: str = '',
            rated_power: Power_kW = 0,
            rated_speed: Speed_rpm = 0,
            bsfc_curve: np.ndarray = None,
            fuel_type: TypeFuel = TypeFuel.HFO,
            shaft_line_id: int = 1,
            file_name: str = None
    ):
        if type(engine) is Engine:
            super().__init__(
                type_=TypeComponent.MAIN_ENGINE,
                name=engine.name,
                rated_power=engine.rated_power,
                rated_speed=engine.rated_speed,
                bsfc_curve=engine.specific_fuel_consumption_points,
                fuel_type=engine.fuel_type
            )
        else:
            super().__init__(
                type_=TypeComponent.MAIN_ENGINE,
                name=name,
                rated_power=rated_power,
                rated_speed=rated_speed,
                bsfc_curve=bsfc_curve,
                fuel_type=fuel_type,
                file_name=file_name
            )
        self.shaft_line_id = shaft_line_id


class MechanicalPropulsionComponent(BasicComponent):
    """
    Mechanical propulsion component class for basic information and efficiency interpolation
    """

    def __init__(
            self,
            type_: TypeComponent,
            power_type: TypePower,
            name: str = '',
            rated_power: Power_kW = 0,
            eff_curve: np.ndarray = np.ndarray([1]),
            rated_speed: Speed_rpm = 0,
            shaft_line_id: int = 1,
            file_name: str = None
    ):
        super(MechanicalPropulsionComponent, self).__init__(
            type_, power_type, name, rated_power, eff_curve, rated_speed, file_name
        )
        self.shaft_line_id = shaft_line_id


class MainEngineWithGearBoxForMechanicalPropulsion(Component):
    def __init__(self, name: str, main_engine: Engine, gearbox: BasicComponent, shaft_line_id: int = 1):
        super(MainEngineWithGearBoxForMechanicalPropulsion, self).__init__(
            name=name, power_type=TypePower.POWER_SOURCE,
            type_=TypeComponent.MAIN_ENGINE, rated_power=main_engine.rated_power,
            rated_speed=main_engine.rated_speed
        )
        self.main_engine = main_engine
        self.gearbox = gearbox
        self.shaft_line_id = shaft_line_id

    def get_fuel_cons_load_bsfc_from_power_out_kw(self, power: np.ndarray = None) -> (
            np.ndarray, np.ndarray, np.ndarray):
        """
        Calculate fuel consumption, percentage load and bsfc for the shaft power before the gearbox
        :param power: single value or ndarray of power in kW
        :return: fuel consumption (kg/h), load (%), bsfc (g/kWh)
        """
        if power is None:
            power = self.power_output
        load_percent = self.get_load(power)
        eff_gearbox = self.gearbox.get_efficiency_from_load_percentage(load_percent)
        return self.main_engine.get_fuel_cons_load_bsfc_from_power_out_kw(power / eff_gearbox)


MechanicalComponent = Union[
    MainEngineForMechanicalPropulsion,
    MainEngineWithGearBoxForMechanicalPropulsion,
    'PTIPTO',
    MechanicalPropulsionComponent
]
