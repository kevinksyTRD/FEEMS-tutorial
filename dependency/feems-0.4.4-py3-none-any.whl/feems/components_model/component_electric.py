from typing import Union, TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from feems.components_model.node import SwbId
from feems.components_model.component_base import (SerialSystem, Component, BasicComponent)
from feems.components_model.component_mechanical import \
    (Engine,
     MainEngineForMechanicalPropulsion,
     MechanicalPropulsionComponent,
     MainEngineWithGearBoxForMechanicalPropulsion)
from feems.components_model.utility import integrate_data_with_regular_time_step
from feems.constant import hhv_hydrogen_mj_per_kg, lhv_hydrogen_mj_per_kg
from feems.types_for_feems import TypeComponent, TypePower, Power_kW, Speed_rpm


class ElectricComponent(BasicComponent):
    """Electric component class for basic information and efficiency interpolation."""

    def __init__(
            self,
            type_: TypeComponent,
            name: str = '',
            rated_power: Power_kW = 1,
            eff_curve: np.ndarray = np.array([1]),
            power_type: TypePower = TypePower.NONE,
            rated_speed: Speed_rpm = 0,
            switchboard_id: 'SwbId' = 0,
            file_name: str = None
    ):
        super().__init__(
            type_=type_, power_type=power_type, name=name,
            rated_power=rated_power, rated_speed=rated_speed,
            eff_curve=eff_curve, file_name=file_name
        )
        self.power_type = power_type
        if power_type in [TypePower.POWER_SOURCE, TypePower.PTI_PTO, TypePower.ENERGY_STORAGE]:
            self.load_sharing_mode = np.zeros(1)
            self.status = np.zeros(0).astype(bool)
        if file_name is not None:
            df = pd.read_csv(file_name, index_col=0)
            self.switchboard_id = df['Switchboard No'].values[0]
        else:
            self.switchboard_id = switchboard_id


class ElectricMachine(ElectricComponent):
    """Electric Machine as a subclass of ElectricComponent"""

    def __init__(
            self, *, type_: TypeComponent, name: str, rated_power: Power_kW, rated_speed: Speed_rpm,
            power_type: TypePower = TypePower.NONE, switchboard_id: 'SwbId' = 0, number_poles: int = 1,
            eff_curve: np.ndarray = np.ones(1)
    ):
        super(ElectricMachine, self).__init__(
            type_=type_, name=name, power_type=power_type, rated_power=rated_power, rated_speed=rated_speed,
            eff_curve=eff_curve, switchboard_id=switchboard_id
        )
        self.number_of_poles = number_poles

    def get_shaft_power_load_from_electric_power(
            self, power_electric: Union[float, np.ndarray], strict_power_balance: bool = False
    ) -> (Union[float, np.ndarray], Union[float, np.ndarray]):
        """
        Calculate the shaft power and load percentage from electric power

        :param power_electric: in kW, for power source component, positive value means the machine is providing powered
            by the shaft side. For power consumer component, positive value means the machine is powered by the electric
            side. For PTI_PTO, positive value means the machine is powered from the electric side (motor) and
            negative value means the machine is powered from the shaft side (generator), ndarray
        :param strict_power_balance: (Optional) If true, it will run iterative method to find the exact solution for
            getting the shaft power. Otherwise, it will use an interpolation function. Default is False.
        :return: power: in kW, positive is the power driving the shaft from the electric machine,
            negative is the power driven from the other end. ndarray, load: load percentage, ndarray
        """
        if self.power_type == TypePower.POWER_SOURCE:
            power_shaft, load = self.get_power_input_from_bidirectional_output(power_electric, strict_power_balance)
        elif self.power_type == TypePower.POWER_CONSUMER or self.power_type == TypePower.PTI_PTO:
            power_shaft, load = self.get_power_output_from_bidirectional_input(power_electric, strict_power_balance)
        else:
            raise TypeError("The type of the component for {} is not properly assigned. "
                              "It should be either power source, power consumer or PTI/PTO.".format(self.name))
        return power_shaft, load

    def get_electric_power_load_from_shaft_power(
            self, power_shaft: Union[float, np.ndarray], strict_power_balance: bool = False
    ) -> (Union[float, np.ndarray], Union[float, np.ndarray]):
        """
        Calculate the electric power and load percentage from shaft power

        :param power_shaft: in kW, for power source component, positive value means the machine is providing powered
            by the shaft side. For power consumer component, positive value means the machine is powered by the electric
            side. For PTI_PTO, positive value means the machine is powered from the electric side (motor) and
            negative value means the machine is powered from the shaft side (generator), ndarray

        :return: power
        """
        if self.power_type == TypePower.POWER_SOURCE:
            power_electric, load = self.get_power_output_from_bidirectional_input(power_shaft, strict_power_balance)
        elif self.power_type == TypePower.POWER_CONSUMER or self.power_type == TypePower.PTI_PTO:
            power_electric, load = self.get_power_input_from_bidirectional_output(power_shaft, strict_power_balance)
        else:
            raise (TypeError, "The type of the component for {} is not properly assigned. "
                              "It should be either power source, power consumer or PTI/PTO.".format(self.name))
        return power_electric, load


class Battery(ElectricComponent):
    """
    Battery class

    :param name: name
    :param rated_capacity_kWh: Energy capacity in kWh
    :param charging_rate_C: Charging rate in C-rate
    :param discharge_rate_C: Discharging rate in C-rate
    :param soc0: Initial SoC in percentage
    :param eff_charging: Charging efficiency in percentage
    :param eff_discharging: Discharging efficiency in percentage
    :param switchboard_id: switchboard ID, if applicable
    """

    def __init__(
            self, name: str, rated_capacity_kWh: float,
            charging_rate_C: float, discharge_rate_C: float,
            soc0: float = 80, eff_charging: float = 97.5, eff_discharging: float = 97.5,
            switchboard_id: 'SwbId' = 0
    ):
        rated_power = Power_kW(rated_capacity_kWh * discharge_rate_C)
        super().__init__(
            TypeComponent.BATTERY, name, rated_power,
            power_type=TypePower.ENERGY_STORAGE, switchboard_id=switchboard_id
        )
        self.rated_capacity_kWh = rated_capacity_kWh
        self.charging_rate_C = charging_rate_C
        self.discharging_rate_C = discharge_rate_C
        self.soc0 = soc0
        self.eff_charging = eff_charging
        self.eff_discharging = eff_discharging

    def get_soc(self, time_interval_s: float, integration_method='simpson'):
        """
        Calculates the SoC based on the power input at the terminal. The power input of the battery should
        have been set.

        :param time_interval_s: time interval for the power_input series
        :param integration_method: 'simpson' or 'trapezoid'. 'simpson' is default value.
        :return: SoC as series
        """
        power_input = self.power_input

        #: Calculate actual power being converted to chemical energy
        index_charging = power_input > 0
        power_input[index_charging] = power_input[index_charging] * self.eff_charging

        #: Calculate actual power being converted from chemical energy
        index_discharging = power_input < 0
        power_input[index_discharging] = power_input[index_discharging] / self.eff_discharging

        #: Calculate soc
        return integrate_data_with_regular_time_step(power_input, time_interval_s, integration_method) / 3600 + \
               self.soc0


class SerialSystemElectric(SerialSystem):
    """
    class for serial system (drive line, DC genset with rectifier) with basic information and
    efficiency interpolation
    """

    def __init__(
            self,
            type_: TypeComponent, name: str,
            power_type: TypePower,
            components: list, switchboard_id: int,
            rated_power: float, rated_speed: float = 0
    ):
        super(SerialSystemElectric, self).__init__(
            type_, power_type, name, components, rated_power, rated_speed
        )

        #: Set the load sharing mode 0 as default value if the component is either a power source,
        #: PTI/PTO or ESS
        if self.power_type in [TypePower.POWER_SOURCE, TypePower.PTI_PTO, TypePower.ENERGY_STORAGE]:
            self.load_sharing_mode = np.zeros(1)
        self.switchboard_id = switchboard_id


class FuelCell(BasicComponent):
    def __init__(self, name: str, rated_power: Power_kW, eff_curve: np.ndarray):
        super(FuelCell, self).__init__(
            type_=TypeComponent.FUEL_CELL, power_type=TypePower.POWER_SOURCE,
            name=name, rated_power=rated_power, eff_curve=eff_curve
        )

    def get_hydrogen_consumption_hhv_kg_per_s(self, power_out_kw: np.ndarray):
        power_in_kw, load = self.get_power_input_from_bidirectional_output(power_out_kw)
        return power_in_kw / hhv_hydrogen_mj_per_kg / 1000

    def get_hydrogen_consumption_lhv_kg_per_s(self, power_out_kw: np.ndarray):
        power_in_kw, load = self.get_power_input_from_bidirectional_output(power_out_kw)
        return power_in_kw / lhv_hydrogen_mj_per_kg / 1000


class FuelCellSystem(ElectricComponent):
    """
    Class for serial config for a fuel cell system. It is composed of a fuel cell module and a converter
    """

    def __init__(self, name: str, fuel_cell_module: FuelCell, converter: ElectricComponent, switchboard_id: int):
        super(FuelCellSystem, self).__init__(
            name=name, type_=TypeComponent.FUEL_CELL_SYSTEM, rated_power=converter.rated_power,
            eff_curve=converter._efficiency_points, power_type=TypePower.POWER_SOURCE, switchboard_id=switchboard_id
        )
        self.converter = converter
        self.fuel_cell = fuel_cell_module

    def get_hydrogen_consumption_hhv_kg_per_s(self, power_out_kw: np.ndarray):
        power_out_fuel_cell_kw, load = self.get_power_input_from_bidirectional_output(power_out_kw)
        return self.fuel_cell.get_hydrogen_consumption_hhv_kg_per_s(power_out_fuel_cell_kw)

    def get_hydrogen_consumption_lhv_kg_per_s(self, power_out_kw: np.ndarray):
        power_out_fuel_cell_kw, load = self.get_power_input_from_bidirectional_output(power_out_kw)
        return self.fuel_cell.get_hydrogen_consumption_lhv_kg_per_s(power_out_fuel_cell_kw)


class BatterySystem(Battery):
    """
    Class for serial configuration for a battery system.
    """

    def __init__(self, name: str, battery: Battery, converter: ElectricComponent, switchboard_id: int):
        super().__init__(
            name=name, rated_capacity_kWh=battery.rated_capacity_kWh,
            charging_rate_C=battery.charging_rate_C,
            discharge_rate_C=battery.discharging_rate_C,
            soc0=battery.soc0, eff_charging=battery.eff_charging,
            eff_discharging=battery.eff_discharging,
            switchboard_id=switchboard_id
        )
        self.rated_power = converter.rated_power
        self.converter = converter
        self.battery = battery

    def get_soc(self, time_interval_s, integration_method='simpson'):
        """Get SoC series based on the power input of the system. The power input of the system should have been set

        :param time_interval_s: time interval in seconds
        :param integration_method: 'simpson' or 'trapezoid'. 'Simpson' is the default value.
        :return: SoC series in percentage
        """
        #: Set the power input of the battery
        self.battery.power_input = self.converter.get_power_output_from_bidirectional_input(self.power_input)

        #: Calculate and return the SoC of the battery
        return self.battery.get_soc(time_interval_s, integration_method)


class Genset(Component):
    """
    Class for serial config for genset. It is composed of an engine, a generator and optionally a rectifier in case
    of DC genset.
    """

    def __init__(self, name: str, aux_engine: Engine,
                 generator: ElectricMachine, rectifier: ElectricComponent = None):
        super(Genset, self).__init__(
            name=name, type_=TypeComponent.GENSET,
            power_type=TypePower.POWER_SOURCE,
            rated_power=generator.rated_power,
            rated_speed=generator.rated_speed
        )
        self.fuel_type = aux_engine.fuel_type
        self.aux_engine = aux_engine
        #: For DC genset, rectifier is included
        if type(rectifier) is ElectricComponent:
            generator_rectifier = SerialSystemElectric(
                name='{:s} with rectifier'.format(generator.name), type_=TypeComponent.GENERATOR,
                components=[generator, rectifier], switchboard_id=generator.switchboard_id,
                power_type=TypePower.POWER_SOURCE, rated_power=rectifier.rated_power,
                rated_speed=generator.rated_speed
            )
            self.generator = ElectricMachine(
                type_=TypeComponent.GENERATOR, name=generator_rectifier.name,
                rated_power=generator.rated_power,
                rated_speed=generator.rated_speed, power_type=TypePower.POWER_SOURCE,
                switchboard_id=generator.switchboard_id,
                number_poles=generator.number_of_poles, eff_curve=generator_rectifier._efficiency_points
            )
        else:
            self.generator = generator
        self.switchboard_id = generator.switchboard_id
        self.status = np.ones(0).astype(bool)
        self.load_sharing_mode = np.zeros(1)

    def get_fuel_cons_load_bsfc_from_power_out_generator_kw(self, power: np.ndarray) \
            -> (np.ndarray, np.ndarray, np.ndarray, np.ndarray):
        """Calculate fuel consumption, percentage load and bsfc for the shaft power before the gearbox

        :param power: single value or ndarray of power in kW
        :return: fuel consumption (kg/s), load (%), bsfc (g/kWh)
        """
        power_shaft, load_percent_generator = self.generator.get_shaft_power_load_from_electric_power(power)
        load_percent_aux_engine = self.aux_engine.get_load(power_shaft)
        bsfc = self.aux_engine.specific_fuel_consumption_interp(load_percent_aux_engine)
        fuel_cons = bsfc * power_shaft / 1000 / 3600
        return fuel_cons, load_percent_aux_engine, bsfc, load_percent_generator


class PTIPTO(SerialSystemElectric):

    def __init__(
            self,
            name: str,
            components: list,
            switchboard_id: int,
            rated_power: float,
            rated_speed: float = 0,
            shaft_line_id: int = 1
    ):
        super(PTIPTO, self).__init__(
            TypeComponent.PTI_PTO, name, TypePower.PTI_PTO,
            components, switchboard_id,
            rated_power, rated_speed
        )
        self.shaft_line_id = shaft_line_id
        self.full_pti_mode = False


class SuperCapacitor(ElectricComponent):
    """
    Supercapacitor class

    :param name: Component name
    :param rated_capacity_Wh: Rated capacity in Wh
    :param rated_power: Rated power in kW
    :param soc0: State of charge in percentage
    :param eff_charging: Efficiency for charging in percentage
    :param eff_discharging: Efficiency for discharging in percentage
    :param switchboard_id: Switchboard ID
    """

    def __init__(
            self, name: str, rated_capacity_Wh: float,
            rated_power: Power_kW, soc0: float = 80.0,
            eff_charging: float = 99.5, eff_discharging: float = 99.5,
            switchboard_id: 'SwbId' = 0
    ):
        super().__init__(
            TypeComponent.SUPERCAPACITOR, name, rated_power,
            power_type=TypePower.ENERGY_STORAGE, switchboard_id=switchboard_id
        )
        self.rated_capacity_Wh = rated_capacity_Wh
        self.soc0 = soc0
        self.eff_charging = eff_charging
        self.eff_discharging = eff_discharging

    def get_soc(self, time_interval_s: float, integration_method='simpson'):
        """
        Calculates the SoC based on the power input at the terminal. The power input of the battery should
        have been set.

        :param time_interval_s: time interval for the power_input series
        :param integration_method: 'simpson' or 'trapezoid'. 'simpson' is default value.
        :return: SoC as series
        """
        power_input = self.power_input

        #: Calculate actual power being converted to chemical energy
        index_charging = power_input > 0
        power_input[index_charging] = power_input[index_charging] * self.eff_charging

        #: Calculate actual power being converted from chemical energy
        index_discharging = power_input < 0
        power_input[index_discharging] = power_input[index_discharging] / self.eff_discharging

        #: Calculate soc
        return integrate_data_with_regular_time_step(power_input, time_interval_s, integration_method) / 3.6 + \
               self.soc0


class SuperCapacitorSystem(SuperCapacitor):
    """
    Class for serial configuration for a SuperCapacitor system.
    """

    def __init__(self, name: str, supercapacitor: SuperCapacitor, converter: ElectricComponent, switchboard_id: int):
        super().__init__(
            name=name, rated_capacity_Wh=supercapacitor.rated_capacity_Wh,
            rated_power=supercapacitor.rated_power,
            soc0=supercapacitor.soc0, eff_charging=supercapacitor.eff_charging,
            eff_discharging=supercapacitor.eff_discharging,
            switchboard_id=switchboard_id
        )
        self.converter = converter
        self.supercapacitor = supercapacitor

    def get_soc(self, time_interval_s, integration_method='simpson'):
        """Get SoC series based on the power input of the system. The power input of the system should have been set.

        :param time_interval_s: time interval in seconds
        :param integration_method: 'simpson' or 'trapezoid'. 'Simpson' is the default value.
        :return: SoC series in percentage
        """
        #: Set the power input of the battery
        self.supercapacitor.power_input = self.converter.get_power_output_from_bidirectional_input(self.power_input)

        #: Calculate and return the SoC of the battery
        return self.supercapacitor.get_soc(time_interval_s, integration_method)


MechanicalComponent = Union[
    MainEngineForMechanicalPropulsion,
    MainEngineWithGearBoxForMechanicalPropulsion,
    PTIPTO,
    MechanicalPropulsionComponent
]
