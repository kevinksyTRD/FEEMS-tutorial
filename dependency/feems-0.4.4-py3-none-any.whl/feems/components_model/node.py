import logging
from typing import Dict, Tuple, List, Union, NewType, Any, cast

import numpy as np
import pandas as pd

from feems.components_model.component_base import (Component, BasicComponent, SerialSystem)
from feems.components_model.component_electric import (ElectricComponent, FuelCellSystem, Genset, MechanicalComponent,
                                                       FuelCell, Battery, BatterySystem, SuperCapacitor,
                                                       SuperCapacitorSystem, PTIPTO)
from feems.components_model.component_mechanical import MainEngineForMechanicalPropulsion
from feems.components_model.utility import integrate_data_with_regular_time_step, IntegrationMethod
from feems.constant import (co2_factor_ton_per_ton_fuel, nox_tier_slow_speed_max_rpm, nox_factor_imo_medium_speed_g_hWh,
                            nox_factor_imo_slow_speed_g_kWh)
from feems.types_for_feems import FEEMSResult, TypeNode, TypePower, TypeComponent


class Node:
    def __init__(self, name: str, type_: TypeNode, components: List[Union[Component, 'Node']]):
        self.name = name
        self.type = type_
        self.status = np.ones(1).astype(bool)
        self.power_out = np.zeros(1)
        self.no_connection = 0
        self.components: List[Component, 'Node'] = components

    def get_power_out(self):
        len_power_values = [len(component.power_input) for component in self.components]
        if not len_power_values:
            return np.zeros(1)
        assert len(set(len_power_values)) == 1, "The length of power consumption values for the " \
                                                "components connected to the {} are not identical.".format(self.name)
        self.power_out = np.zeros(len_power_values[0])
        for component in self.components:
            self.power_out += component.power_input


SwbId = NewType('SwbId', Any)


class Switchboard(Node):
    def __init__(self, name: str, idx: SwbId, components: List[ElectricComponent]):
        super(Switchboard, self).__init__(name=name, type_=TypeNode.SWITCHBOARD, components=components)
        self.id: SwbId = idx
        self.component_by_power_type: List[List[Union[ElectricComponent, Genset, FuelCellSystem]]] = \
            [[] for power in TypePower]
        self.name_component_by_power_type = [[] for power in TypePower]
        #: Categorize the components by its power type
        for component in components:
            self.component_by_power_type[component.power_type.value].append(component)
            self.name_component_by_power_type[component.power_type.value].append(component.name)
        #: Check if the names are duplicates in each category
        for i, name_list in enumerate(self.name_component_by_power_type):
            name_list_unique = list(set(name_list))
            if len(name_list) != len(name_list_unique):
                raise NameError("There are duplicates in the component name for {0} "
                                "category for the switchboard no. {1}".format(TypePower(i).name, self.id))
        #: Rated power for the bus (summing all the rated power of the power sources)
        self.rated_power = sum([component.rated_power for component in
                                self.component_by_power_type[TypePower.POWER_SOURCE.value]])
        self.no_power_sources = len(self.component_by_power_type[TypePower.POWER_SOURCE.value])
        self.no_consumers = len(self.component_by_power_type[TypePower.POWER_CONSUMER.value])
        self.no_pti_pto = len(self.component_by_power_type[TypePower.PTI_PTO.value])
        self.no_energy_storage = len(self.component_by_power_type[TypePower.ENERGY_STORAGE.value])

    def get_status_component_by_power_type(self, type_: TypePower) -> List[np.ndarray]:
        #: Check if the length of the values for different components are the same
        len_status = [len(component.status) for component in
                      self.component_by_power_type[type_.value]]
        if not len_status:
            return [False]
        assert len(set(len_status)) == 1, "The length of status values for the power source " \
                                          "connected to the {} are not identical.: {}".format(self.name, len_status)
        return [component.status for component in
                self.component_by_power_type[type_.value]]

    def get_load_sharing_mode_components_by_power_type(self, type_: TypePower) -> List[np.ndarray]:
        #: Check if the length of the values for different components are the same
        len_load_sharing = [len(component.load_sharing_mode) for component in
                            self.component_by_power_type[type_.value]]
        if not len_load_sharing:
            return [0]
        assert len(set(len_load_sharing)) == 1, "The length of load sharing values for the power source connected " \
                                                "to the {} are not identical.: {}".format(self.name, len_load_sharing)
        return [component.load_sharing_mode for component in
                self.component_by_power_type[type_.value]]

    def get_power_rated_component_by_power_type(self, type_: TypePower) -> List[float]:
        return [power_source.rated_power for power_source in self.component_by_power_type[type_.value]]

    def get_power_avail_component_by_power_type(self, type_: TypePower) -> List[np.ndarray]:
        #: Check if the length of the values for different components are the same
        len_status = [len(component.status) for component in
                      self.component_by_power_type[type_.value]]
        if not len_status:
            return [np.array([0])]
        assert len(set(len_status)) == 1, "The length of load sharing values for the power source connected to " \
                                          "the {} are not identical.: {}".format(self.name, len_status)
        return [component.rated_power * component.status for component in
                self.component_by_power_type[type_.value]]

    def get_sum_power_input_by_power_type(self, type_: TypePower) -> np.ndarray:
        """
        Return the sum of power input value or vectors of the components specified by the power type.
        Note that the power input values of the components that have 0 values for the corresponding load sharing mode
        (Equally load sharing mode) will be excluded from the sum
        """
        #: Check if the length of the values for different components are the same
        len_power_values = [len(component.power_input) for component in
                            self.component_by_power_type[type_.value]]
        if not len_power_values:
            return np.zeros(1)
        assert len(set(len_power_values)) <= 1, "The length of power consumption values for the components " \
                                                "connected to the {} are not identical.".format(self.name)
        power_input_sum = np.zeros(len_power_values[0])
        for component in self.component_by_power_type[type_.value]:
            if component.power_type == TypePower.PTI_PTO or component.power_type == TypePower.ENERGY_STORAGE:
                power_input_sum += component.power_input * component.load_sharing_mode
            else:
                power_input_sum += component.power_input
        return power_input_sum

    def _get_component_by_type_and_name(
            self,
            name: str,
            power_type: TypePower,
    ) -> BasicComponent:
        try:
            idx = self.name_component_by_power_type[power_type.value].index(name)
            return self.component_by_power_type[power_type.value][idx]
        except ValueError:
            raise ValueError("The name does not match the components for the given type")

    def set_power_load_component_from_power_input_by_type_and_name(
            self,
            name: str,
            power_type: TypePower,
            power_input: np.ndarray
    ) -> int:
        """
        Set the power input and output from the given value of power input
        for a component specified by the type and the name.
        :param name: name of the component
        :param power_type: type defined by TypePower Class
        :param power_input: power output of the component
        :return: 1 for success and 0 for error
        """
        component = self._get_component_by_type_and_name(name, power_type)
        if component is not None:
            component.set_power_input_from_output(power_input)
            return 1
        else:
            return 0

    def set_power_load_component_from_power_output_by_type_and_name(
            self, name: str, power_type: TypePower, power_output: np.ndarray
    ):
        """
        Set the power input and output from the given value of power output
        for a component specified by the type and the name
        :param name: name of the component
        :param power_type: type defined by TypePower Class
        :param power_output: power output of the component
        :return: 1 for success and 0 for error
        """
        component = self._get_component_by_type_and_name(name, power_type)
        component.set_power_input_from_output(power_output)

    def set_status_components_by_power_type(self, type_: TypePower, status: np.ndarray):
        """
        Set the status of all the power sources

        :param type: power type as listed in TypePower class
        :param status: 2d array of bool with dimension [N x n] where n is the number of power sources
        """
        no_components = len(self.component_by_power_type[type_.value])
        if len(status.shape) != 2:
            raise ValueError("The status input should be a 2D matrix")
        elif status.shape[1] != no_components:
            if status.shape[0] == no_components:
                raise ValueError("The dimension of the status input should be transposed")
            else:
                raise ValueError("The dimension of the status input does not match the number of power sources")
        for i, component in enumerate(self.component_by_power_type[type_.value]):
            component.status = status[:, i]

    def set_status_component_by_power_type_name(self, status: np.ndarray, name: str):
        """
        Sets the status of the power source specified by the name
        :param status: 1d array of bool
        :param name: The name of the power source
        :return: 1 for success, 0 for error
        """
        try:
            index = self.name_component_by_power_type[TypePower.POWER_SOURCE.value].index(name)
        except ValueError:
            raise ValueError("The name given for the power source is not found in the switchboard")
        self.component_by_power_type[TypePower.POWER_SOURCE.value][index].status = status
        return 1

    def set_status_components_by_power_type_and_index(self, type_: TypePower, status: np.ndarray, index: int):
        """
        Sets the status of the power source specified by the index
        :param type_: power type as listed in TypePower
        :param status: 1d array of bool
        :param index: The index of the components in the list
        :return: 1 for success, 0 for error
        """
        if index >= len(self.component_by_power_type[type_.value]) or index < 0:
            raise ValueError("The index exceeds the length of the list of power sources or negative")
        self.component_by_power_type[type_.value][index].status = status
        return 1

    def set_load_sharing_mode_components_by_power_type(self, type_: TypePower, load_sharing_mode: np.ndarray):
        for i, component in enumerate(self.component_by_power_type[type_.value]):
            component.load_sharing_mode = load_sharing_mode[:, i]

    def get_sum_power_out_power_sources_asymmetric(self) -> np.ndarray:
        return (
                np.array(self.get_load_sharing_mode_components_by_power_type(TypePower.POWER_SOURCE)) *
                np.array(self.get_power_avail_component_by_power_type(TypePower.POWER_SOURCE))
        ).sum(axis=0)

    def get_sum_power_avail_for_power_sources_asymmetric_by_type(self, type_: TypePower = TypePower.POWER_SOURCE) \
            -> np.ndarray:
        return (
                np.ceil(np.absolute(np.array(self.get_load_sharing_mode_components_by_power_type(type_)))) *
                np.array(self.get_power_avail_component_by_power_type(type_))
        ).sum(axis=0)

    def get_sum_power_avail_for_power_sources_symmetric(self) -> np.ndarray:
        sum_power_avail_power_sources = np.array(
            self.get_power_avail_component_by_power_type(TypePower.POWER_SOURCE)
        ).sum(axis=0).astype(float)
        sum_power_avail_pti_pto = np.array(
            self.get_power_avail_component_by_power_type(TypePower.PTI_PTO)
        ).sum(axis=0).astype(float)
        sum_power_avail_energy_storage = np.array(
            self.get_power_avail_component_by_power_type(TypePower.ENERGY_STORAGE)
        ).sum(axis=0).astype(float)
        sum_power_avail_power_source_asymm = self.get_sum_power_avail_for_power_sources_asymmetric_by_type(
            TypePower.POWER_SOURCE
        )
        sum_power_avail_pti_pto_asymm = self.get_sum_power_avail_for_power_sources_asymmetric_by_type(
            TypePower.PTI_PTO
        )
        sum_power_avail_energy_storage_asymm = self.get_sum_power_avail_for_power_sources_asymmetric_by_type(
            TypePower.ENERGY_STORAGE
        )
        return sum_power_avail_power_sources + sum_power_avail_pti_pto + sum_power_avail_energy_storage - \
               sum_power_avail_power_source_asymm - sum_power_avail_pti_pto_asymm - sum_power_avail_energy_storage_asymm

    def get_sum_load_kw_sources_symmetric(self) -> np.ndarray:
        sum_power_consumption = self.get_sum_power_input_by_power_type(TypePower.POWER_CONSUMER)
        sum_power_pti_pto = self.get_sum_power_input_by_power_type(TypePower.PTI_PTO)
        sum_power_energy_storage = self.get_sum_power_input_by_power_type(TypePower.ENERGY_STORAGE)
        sum_power_power_source_asymm = self.get_sum_power_out_power_sources_asymmetric()
        return sum_power_consumption + sum_power_pti_pto + sum_power_energy_storage - sum_power_power_source_asymm

    def get_sum_power_output_by_power_type(self, type_: TypePower) -> np.ndarray:
        """
        Return the sum of power output value or vectors of the components specified by the power type.
        Note that the power input values of the components that have 0 values for the corresponding load sharing mode
        (Equally load sharing mode) will be excluded from the sum
        """
        #: Check if the length of the values for different components are the same
        len_power_values = [len(component.power_output) for component in
                            self.component_by_power_type[type_.value]]
        if not len_power_values:
            return np.zeros(1)
        assert len(set(len_power_values)) <= 1, "The length of power consumption values for the components " \
                                                "connected to the {} are not identical.".format(self.name)
        power_output_sum = np.zeros(len_power_values[0])
        for component in self.component_by_power_type[type_.value]:
            if component.power_type == TypePower.PTI_PTO or component.power_type == TypePower.ENERGY_STORAGE:
                power_output_sum += component.power_output * component.load_sharing_mode
            else:
                power_output_sum += component.power_output
        return power_output_sum

    def set_power_out_power_sources(self, load_switchboard_symmetric_power_source: np.ndarray):
        """
        Set the power out for the power sources in symmetric and asymmetric load sharing mode.
        The power sources have the power type of TypePower.POWER_SOURCE, TypePower.PTI_PTO and
        TypePower.ENERGY_STORAGE. For PTI/PTO and energy storage, power input should be set
        manually when the load sharing mode is not symmetric.
        :param load_switchboard_symmetric_power_source: the load (0~1) on the switchboard for
        the power sources that share the power load symmetrically. 1d array
        :return: 1 for success, 0 for error
        """
        no_points = len(load_switchboard_symmetric_power_source)
        for component in self.component_by_power_type[TypePower.POWER_SOURCE.value]:
            power_out = np.zeros(no_points)
            index_symmetric_load = component.load_sharing_mode == 0
            try:
                power_out[index_symmetric_load] = component.rated_power * \
                                                  load_switchboard_symmetric_power_source[index_symmetric_load] * \
                                                  component.status[index_symmetric_load]
            except IndexError:
                raise ValueError(
                    "The length of the input (load_switchboard) does not match the length of load sharing mode of "
                    "the component, {}.".format(component.name))
            index_asymmetric_load = np.bitwise_not(index_symmetric_load)
            power_out[index_asymmetric_load] = component.rated_power * \
                                               component.load_sharing_mode[index_asymmetric_load] * component.status[
                                                   index_asymmetric_load]
            component.power_output = power_out
        for component in self.component_by_power_type[TypePower.PTI_PTO.value] + \
                         self.component_by_power_type[TypePower.ENERGY_STORAGE.value]:
            index_symmetric_load = component.load_sharing_mode == 0
            try:
                component.power_input[index_symmetric_load] = \
                    - component.rated_power * load_switchboard_symmetric_power_source[index_symmetric_load] * \
                    component.status[index_symmetric_load]
            except IndexError:
                raise ValueError(
                    "The length of the input (load_switchboard) does not match the length of the power input / "
                    "output values for the component, {}".format(component.name))
            component.power_output, load_perc = \
                component.get_power_output_from_bidirectional_input(component.power_input)

    def get_fuel_energy_consumption_running_time(
            self, time_interval_s: Union[float, np.ndarray], nox_emission_criteria: int = 2,
            integration_method: IntegrationMethod = IntegrationMethod.simpson
    ) -> FEEMSResult:
        '''
        Calculates fuel/energy consumption at the shaftline. Power output of the main engines and PTI/PTO
        should have set manually or by power balance calculation.

        :param time_interval_s: time interval for power output data
        :param nox_emission_criteria: IMO NOx emission tier 1, 2, 3
        :param integration_method: 'simpson' or 'trapezoid'. 'simpson' is default value
        :return: FEEM fuel_consumption_total, hydrogen_consumption_total, energy_consumption_electrical_total, \
            energy_consumption_mechanical_total, running_hours_genset_total, running_hours_fuel_cell_total, \
            running_hours_pti_pto, co2_emission, nox_emission, result_dataframe.
            result_dataframe is DataFrame that contains detail for each machinery
        '''
        #: Create a empty data frame for the result_dataframe
        column_names = [
            'fuel consumption [kg]',
            'electric energy consumption [MJ]',
            'mechanical energy consumption [MJ]',
            'running hours [h]',
            'CO2 emission [kg]',
            'NOx emission [kg]',
            'component type',
            'rated capacity',
            'rated capacity unit',
        ]

        result_dataframe = pd.DataFrame(columns=column_names)

        #: Get the fuel consumption / running hours for each power source, pti/pto, energy_storage component
        for component in self.components:
            if component in \
                    self.component_by_power_type[TypePower.POWER_SOURCE.value] + \
                    self.component_by_power_type[TypePower.PTI_PTO.value] + \
                    self.component_by_power_type[TypePower.ENERGY_STORAGE.value]:
                #: Set initial values
                fuel_consumption = 0
                co2_emission_kg = 0
                nox_emission_kg = 0
                energy_consumption_mechanical_mj = 0
                energy_consumption_electric_mj = 0

                #: Rated power
                if component.type in [TypeComponent.BATTERY, TypeComponent.BATTERY_SYSTEM]:
                    if hasattr(component, 'rated_capacity_kWh'):
                        rated_capacity = component.rated_capacity_kWh
                        rated_capacity_unit = 'kWh'
                    else:
                        rated_capacity = component.rated_power
                        rated_capacity_unit = 'kW'
                elif component.type in [TypeComponent.SUPERCAPACITOR, TypeComponent.SUPERCAPACITOR_SYSTEM]:
                    if hasattr(component, 'rated_capacity_Wh'):
                        rated_capacity = component.rated_capacity_Wh
                        rated_capacity_unit = 'Wh'
                    else:
                        rated_capacity = component.rated_power
                        rated_capacity_unit = 'kW'
                else:
                    rated_capacity = component.rated_power
                    rated_capacity_unit = 'kW'

                #: Calculate fuel consumption for genset
                if component.type == TypeComponent.GENSET:
                    component = cast(Genset, component)
                    fuel_consumption_rate, _, _, _ = \
                        component.get_fuel_cons_load_bsfc_from_power_out_generator_kw(component.power_output)
                    fuel_consumption = integrate_data_with_regular_time_step(
                        data_to_integrate=fuel_consumption_rate,
                        time_interval_s=time_interval_s,
                        integration_method=integration_method
                    )
                    co2_emission_kg = fuel_consumption * co2_factor_ton_per_ton_fuel[component.aux_engine.fuel_type]
                    if component.rated_speed > nox_tier_slow_speed_max_rpm:
                        nox_factor_g_kWh = nox_factor_imo_medium_speed_g_hWh[nox_emission_criteria][0] * \
                                           np.power(component.rated_speed,
                                                    nox_factor_imo_medium_speed_g_hWh[nox_emission_criteria][1])
                    else:
                        nox_factor_g_kWh = nox_factor_imo_slow_speed_g_kWh[nox_emission_criteria]
                    nox_emission_rate_kg_s = component.power_output * nox_factor_g_kWh / 1000 / 3600
                    nox_emission_kg = integrate_data_with_regular_time_step(
                        data_to_integrate=nox_emission_rate_kg_s,
                        time_interval_s=time_interval_s,
                        integration_method=integration_method
                    )

                #: Calculate fuel consumption for fuel cell
                elif component.type in [TypeComponent.FUEL_CELL_SYSTEM, TypeComponent.FUEL_CELL]:
                    component = cast(Union[FuelCellSystem, FuelCell], component)
                    fuel_consumption_rate = \
                        component.get_hydrogen_consumption_lhv_kg_per_s(component.power_output)
                    fuel_consumption = integrate_data_with_regular_time_step(
                        data_to_integrate=fuel_consumption_rate,
                        time_interval_s=time_interval_s,
                        integration_method=integration_method
                    )

                #: Calculate mechanical energy consumption for generator / PTI/PTO
                elif component.type in [TypeComponent.GENERATOR, TypeComponent.PTI_PTO]:
                    # power_input, load = component.get_power_input_from_bidirectional_output(component.power_output)
                    energy_consumption_mechanical_mj = integrate_data_with_regular_time_step(
                        data_to_integrate=component.power_output,
                        time_interval_s=time_interval_s,
                        integration_method=integration_method
                    ) / 1000

                #: Calculate electric energy consumption for energy storage system
                elif component.power_type == TypePower.ENERGY_STORAGE:
                    component = cast(Union[Battery, BatterySystem, SuperCapacitor, SuperCapacitorSystem], component)
                    power_input, load_perc = component.get_power_input_from_bidirectional_output(component.power_output)
                    energy_consumption_electric_mj = integrate_data_with_regular_time_step(
                        data_to_integrate=power_input,
                        time_interval_s=time_interval_s,
                        integration_method=integration_method
                    ) / 1000

                #: Calculate running hours
                running_hours = (component.power_output != 0).sum() * time_interval_s / 3600

                #: Add the calculation to the result_dataframe
                data_to_add = [
                    fuel_consumption,
                    energy_consumption_electric_mj,
                    energy_consumption_mechanical_mj,
                    running_hours,
                    co2_emission_kg,
                    nox_emission_kg,
                    component.type.name,
                    rated_capacity,
                    rated_capacity_unit
                ]

                result_dataframe = result_dataframe.append(
                    pd.Series(data_to_add, index=column_names, name=component.name)
                )

        #: Get the index for each component type in the result_dataframe
        index_for_genset = result_dataframe[column_names[6]] == TypeComponent.GENSET.name
        index_for_fuel_cell = (result_dataframe[column_names[6]] == TypeComponent.FUEL_CELL.name) | \
                              (result_dataframe[column_names[6]] == TypeComponent.FUEL_CELL_SYSTEM.name)
        index_for_generator = result_dataframe[column_names[6]] == TypeComponent.GENERATOR.name
        index_for_pti_pto = result_dataframe[column_names[6]] == TypeComponent.PTI_PTO.name
        index_for_energy_storage = result_dataframe[column_names[6]] == TypeComponent.BATTERY_SYSTEM.name

        #: Calculate total consumption values
        fuel_consumption_total = result_dataframe[index_for_genset][column_names[0]].sum()
        hydrogen_consumption_total = result_dataframe[index_for_fuel_cell][column_names[0]].sum()
        energy_consumption_mechanical_total = \
            result_dataframe[index_for_generator | index_for_pti_pto][column_names[2]].sum()
        energy_consumption_electrical_total = result_dataframe[index_for_energy_storage][column_names[1]].sum()

        #: Calculate total running hours
        running_hours_genset_total = result_dataframe[index_for_genset | index_for_generator][column_names[3]].sum()
        running_hours_fuel_cell_total = result_dataframe[index_for_fuel_cell][column_names[3]].sum()
        running_hours_pti_pto = result_dataframe[index_for_pti_pto][column_names[3]].sum()

        #: Calculate total emission values
        co2_emission_total_kg = result_dataframe[index_for_genset][column_names[4]].sum()
        nox_emission_total_kg = result_dataframe[index_for_pti_pto][column_names[5]].sum()

        result = FEEMSResult(
            fuel_consumption_total_kg=fuel_consumption_total,
            hydrogen_consumption_total_kg=hydrogen_consumption_total,
            energy_consumption_electric_total_MJ=energy_consumption_electrical_total,
            energy_consumption_mechanical_total_MJ=energy_consumption_mechanical_total,
            running_hours_genset_total_hr=running_hours_genset_total,
            running_hours_fuel_cell_total_hr=running_hours_fuel_cell_total,
            running_hours_pti_pto_total_hr=running_hours_pti_pto,
            co2_emission_total_kg=co2_emission_total_kg,
            nox_emission_total_kg=nox_emission_total_kg,
            detail_result=result_dataframe
        )

        return result


class BusBreaker(Node):
    """
    class for circuit breaker
    """

    def __init__(self, name: str, switchboard_ids: Tuple[int, int], switchboards: List[Switchboard]):
        super(BusBreaker, self).__init__(name=name, type_=TypeNode.BUS_TIE_BREAKER, components=switchboards)
        self.no_connection = 2
        self.switchboard_ids = switchboard_ids
        self.switchboards = switchboards


class ShaftLine(Node):
    """
    class for main interface for the mechanical propulsion system.
    """

    def __init__(
            self,
            name: str,
            shaft_line_id: int,
            component_list: List[MechanicalComponent]
    ):
        super(ShaftLine, self).__init__(name, TypeNode.SHAFTLINE, component_list)
        self.id = shaft_line_id
        self.component_by_power_type: Dict[
            TypePower,
            List[MechanicalComponent]] = {}
        self.name_component_by_power_type: Dict[TypePower, List[str]] = {}

        #: Categorize the components by its power type
        for component in component_list:
            if component.power_type not in self.component_by_power_type.keys():
                self.component_by_power_type[component.power_type] = [component]
                self.name_component_by_power_type[component.power_type] = [component.name]
            else:
                self.component_by_power_type[component.power_type].append(component)
                self.name_component_by_power_type[component.power_type].append(component.name)

        #: Check if the names are duplicates in each category
        for power_type, name_list in self.name_component_by_power_type.items():
            name_list_unique = list(set(name_list))
            if len(name_list) != len(name_list_unique):
                msg = "There are duplicates in the component name for %s" \
                      "category for the %s" % (power_type, self.name)
                raise NameError(msg)

        #: Get the summary of the system
        self.no_power_sources = len(self.component_by_power_type[TypePower.POWER_SOURCE])
        self.no_consumers = len(self.component_by_power_type[TypePower.POWER_CONSUMER])
        self.no_pti_pto = len(self.component_by_power_type[TypePower.PTI_PTO])

    def get_component_by_name_power_type(self, name: str, power_type: TypePower) \
            -> Union[BasicComponent, SerialSystem, None]:
        #: Find the component by the given name. If not found, log it as error and return 0
        name_component_list = self.name_component_by_power_type[power_type]
        try:
            return self.component_by_power_type[power_type][name_component_list.index(name)]
        except ValueError:
            raise ValueError('The given name is not found among the power consumer components in the %s.' % self.name)

    def set_power_input_load_by_name(self, name: str, power_input: Union[float, np.ndarray]) \
            -> (Union[float, np.ndarray], Union[float, np.ndarray]):
        """
        Sets power input value for the load on the component specified by the name
        :param name: name of the component
        :param power_input: power input to the load in kW. Scalar or 1D ndarray
        :return: 1 for success 0 for error
        """
        #: Get the load component from the name
        component = self.get_component_by_name_power_type(name, TypePower.POWER_CONSUMER)

        #: Set the power_input
        if component is not None:
            component.power_input = \
                np.array([power_input]) if type(component.power_input) is float else power_input
        else:
            return 0

    def set_status_main_engine_by_name(self, name, status: Union[bool, np.ndarray]) -> int:
        """
        Sets the status of main engine (0: off, 1: on) of the given name
        :param name: name of the main engine as in the component instance
        :param status: True or False for on or off respectively. Scalar or 1d ndarray of boolean
        :return: 1 for success, 0 for error
        """
        #: Get the main engine component from the name
        component = self.get_component_by_name_power_type(name, TypePower.POWER_SOURCE)

        #: Set the status of the main engine
        if component is not None:
            component.status = np.array([status]) if type(component.status) is bool else status
        else:
            return 0

    def set_power_output_pti_pto(self, power_output: Union[float, np.ndarray]) \
            -> (Union[float, np.ndarray], Union[float, np.ndarray]):
        """
        Sets the power output (Shaft power) for PTI/PTO. Positive power output means that the
        power is supplied from the electric power grid to the shaft (PTI mode). Negative means
        that the power is supplied from the shaft to the electrical power grid. (PTO mode).
        Setting power output will also set the electric power input by calculating the system efficiency
        :param power_output: Shaft power of PTI/PTO
        :return: power_input and load %
        """
        #: Get the component instance
        try:
            pti_pto = self.component_by_power_type[TypePower.PTI_PTO][0]
        except (IndexError, KeyError) as e:
            raise ValueError("PTI/PTO doesn't exist in the %s" % self.name)

        #: Set the power output
        pti_pto.power_output = np.array([power_output]) if type(power_output) is float else power_output
        pti_pto.power_input, load = pti_pto.get_power_input_from_bidirectional_output(pti_pto.power_output)

        return pti_pto.power_input, load

    def set_power_input_pti_pto(self, power_input: Union[float, np.ndarray]) \
            -> (Union[float, np.ndarray], Union[float, np.ndarray]):
        """
        Sets the power input (electric power) for PTI/PTO. Positive power output means that the
        power is supplied from the electric power grid to the shaft (PTI mode). Negative means
        that the power is supplied from the shaft to the electrical power grid. (PTO mode).
        Setting power input will also set the shaft power output by calculating the system efficiency
        :param power_input: Electric power of PTI/PTO
        :return: power_output (Shaft power) and load %
        """
        #: Get the component instance
        try:
            pti_pto = self.component_by_power_type[TypePower.PTI_PTO][0]
        except (IndexError, KeyError) as e:
            msg = "PTI/PTO doesn't exist in the %s" % self.name
            logging.error(msg)
            raise e

        #: Set the power output
        pti_pto.power_input = np.array([power_input]) if type(power_input) is float else power_input
        pti_pto.power_output, load = pti_pto.get_power_output_from_bidirectional_input(pti_pto.power_input)

        return pti_pto.power_output, load

    def do_power_balance(self) -> (np.ndarray, np.ndarray):
        """
        Calculate the main engine power / PTT and set their as power output.
        Following has be to be done before calling this function.
        - Power input of all the load components set
        - Power input or output of PTI/PTO set except full PTI mode
        - Status of main engines set
        """

        #: Calculate the total power load
        total_power_load = 0
        for component in self.component_by_power_type[TypePower.POWER_CONSUMER]:
            try:
                total_power_load += component.power_input
            except ValueError:
                msg = 'The dimension of the power input of the component (%s) ' \
                      'is not the same as other components' % component.name
                raise ValueError(msg)

        #: Get the PTI/PTO power output
        #: In case of full PTI mode, the PTI should cover all the load alone
        try:
            pti_pto = self.component_by_power_type[TypePower.PTI_PTO][0]
            pti_pto = cast(PTIPTO, pti_pto)
        except (IndexError, KeyError):
            power_output_pti_pto = 0
        else:
            #: For full PTI mode, PTI covers all the load. Set the power input accordingly
            power_output_pti_pto = pti_pto.power_output
            power_output_pti_pto[pti_pto.full_pti_mode] = total_power_load[pti_pto.full_pti_mode]  # TODO BUG
            pti_pto.set_power_input_from_output(power_output_pti_pto)

        #: Calculate the main engine power output
        try:
            power_output_main_engine = total_power_load - power_output_pti_pto
        except ValueError:
            msg = 'The dimension of the power output of the PTI/PTO (%s) ' \
                  'is not the same as other components' % pti_pto.name
            logging.error(msg)
            raise ValueError(msg)

        #: calculate the total power available from the main engines
        total_power_avail = 0
        for main_engine in self.component_by_power_type[TypePower.POWER_SOURCE]:
            total_power_avail += main_engine.rated_power * main_engine.status.astype(float)

        #: Calculate the load percentage
        load_perc = power_output_main_engine / total_power_avail
        load_perc[pti_pto.full_pti_mode] = 0

        #: Set all the power output of the main engine
        for main_engine in self.component_by_power_type[TypePower.POWER_SOURCE]:
            main_engine.power_output = main_engine.rated_power * load_perc * main_engine.status

            #: Set the status false(off) if the power output is 0
            main_engine.status[main_engine.power_output == 0] = False

            #: Check the power balance (negative power for :
            if len(main_engine.power_output[main_engine.power_output < 0]) > 0:
                msg = "There are cases with negative power outputs for the main engine"
                logging.warning(msg)

        return load_perc, total_power_avail

    def get_fuel_calculation_running_hours(
            self, time_step: float, nox_emission_criteria: int = 2, integration_method='simpson'
    ) -> FEEMSResult:
        """
        Calculate fuel consumption and running hours.
        Power balance calculation has to be done in advance.
        :param nox_emission_criteria: IMO NOx tier 1, 2, 3
        :param time_step: time step for the time series in seconds
        :param integration_method: 'simpson' or 'trapezoid'. 'simpson' is the default method.
        :return: FEEMResult with total fuel consumption [kg], total_mechanical_energy_input [MJ],
            total running hours for engines[hours], CO2 emissions [kg], NOx emissions [kg] and
            the detail numbers for each engine and PTI/PTO
        """
        #: Get the main engine instances and collect the names
        main_engines = self.component_by_power_type[TypePower.POWER_SOURCE]
        pti_ptos = self.component_by_power_type[TypePower.PTI_PTO]
        names_main_engines = [main_engine.name for main_engine in main_engines]
        names_pti_ptos = [pti_pto.name for pti_pto in pti_ptos]

        #: Create a dataframe template for the result
        column_names = [
            'fuel consumption [kg]',
            'mechanical energy consumption [MJ]',
            'running hours [h]',
            'CO2 emission [kg]',
            'NOx emission [kg]',
            'component type',
            'shaft line id',
            'rated capacity',
            'rated capacity unit',
        ]
        data_initial = np.zeros([len(names_main_engines + names_pti_ptos), len(column_names)])
        detail_result = pd.DataFrame(data_initial, columns=column_names, index=names_main_engines + names_pti_ptos)

        #: Get the fuel consumption rate and on time for each engine / integrate them
        for main_engine in main_engines:
            #: Rated capacity
            detail_result[column_names[7]][main_engine.name] = main_engine.rated_power
            detail_result[column_names[8]][main_engine.name] = 'kW'

            #: Calculate fuel consumption
            fuel_consumption_rate, _, _ = main_engine.get_fuel_cons_load_bsfc_from_power_out_kw()
            fuel_consumption_kg = integrate_data_with_regular_time_step(
                fuel_consumption_rate, time_step, integration_method
            )
            detail_result[column_names[0]][main_engine.name] = fuel_consumption_kg

            #: Calculate CO2 emission
            co2_factor = co2_factor_ton_per_ton_fuel[main_engine.fuel_type] \
                if type(main_engine) is MainEngineForMechanicalPropulsion else \
                co2_factor_ton_per_ton_fuel[main_engine.main_engine.fuel_type]

            co2_emission_kg = fuel_consumption_kg * co2_factor
            detail_result[column_names[3]][main_engine.name] = co2_emission_kg

            #: Calculate NOx emission
            nox_factor_g_kWh = nox_factor_imo_slow_speed_g_kWh[nox_emission_criteria] \
                if main_engine.rated_speed <= nox_tier_slow_speed_max_rpm else \
                nox_factor_imo_medium_speed_g_hWh[nox_emission_criteria][0] * \
                np.power(main_engine.rated_speed, nox_factor_imo_medium_speed_g_hWh[nox_emission_criteria][1])
            nox_emission_rate_kg_s = main_engine.power_output * nox_factor_g_kWh / 1000 / 3600
            nox_emission_kg = integrate_data_with_regular_time_step(nox_emission_rate_kg_s, time_step)
            detail_result[column_names[4]][main_engine.name] = nox_emission_kg

            #: Calculate running hours
            detail_result[column_names[2]][main_engine.name] = main_engine.status.sum() * time_step / 3600
            detail_result[column_names[5]][main_engine.name] = TypeComponent.MAIN_ENGINE.name
            detail_result[column_names[6]][main_engine.name] = main_engine.shaft_line_id

        for pti_pto in pti_ptos:
            #: Rated power
            detail_result[column_names[7]][pti_pto.name] = pti_pto.rated_power
            detail_result[column_names[8]][pti_pto.name] = 'kW'
            #: Integrate the power output for mechanical energy consumption
            #: Here, it is negative because the power output is positive at motoring mode.
            detail_result[column_names[1]][pti_pto.name] = -1 * integrate_data_with_regular_time_step(
                pti_pto.power_output, time_step, integration_method
            ) / 1000
            #: Running hours
            detail_result[column_names[2]][pti_pto.name] = (pti_pto.power_output != 0).sum() * time_step / 3600
            #: Component Type
            detail_result[column_names[5]][pti_pto.name] = TypeComponent.PTI_PTO.name
            #: Shaft line id
            detail_result[column_names[6]][pti_pto.name] = pti_pto.shaft_line_id

        result = FEEMSResult(
            fuel_consumption_total_kg=detail_result[column_names[0]].sum(),
            energy_consumption_mechanical_total_MJ=detail_result[column_names[1]].sum(),
            running_hours_main_engines_hr=detail_result[column_names[2]].sum(),
            co2_emission_total_kg=detail_result[column_names[3]].sum(),
            nox_emission_total_kg=detail_result[column_names[4]].sum(),
            detail_result=detail_result
        )

        return result
