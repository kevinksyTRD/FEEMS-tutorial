from feems.types_for_feems import TypeFuel

hhv_hydrogen_mj_per_kg = 141.8
lhv_hydrogen_mj_per_kg = 119.96

#: CO2 factor
#: Sources : EEDI, https://marine.mandieselturbo.com/docs/default-source/shopwaredocumentsarchive/eedi.pdf?sfvrsn=4
co2_factor_ton_per_ton_fuel = {
    TypeFuel.HFO: 3.114,
    TypeFuel.LSHFO: 3.114,
    TypeFuel.DIESEL: 3.205,
    TypeFuel.LNG: 2.75,
}

#: NOx factor
nox_factor_imo_slow_speed_g_kWh = {
    1: 17.0,
    2: 14.4,
    3: 3.4,
}
nox_tier_slow_speed_max_rpm = 130
nox_factor_imo_medium_speed_g_hWh = {
    1: (45, -9.2),
    2: (44, -0.23),
    3: (9, -0.2)
}
