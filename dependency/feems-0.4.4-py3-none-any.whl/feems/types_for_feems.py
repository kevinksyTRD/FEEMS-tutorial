from enum import Enum, unique
from typing import NewType, NamedTuple

import numpy as np
import pandas as pd

Power_kW = NewType('power_kW', float)
power_array_kW = NewType('power_array_kW', np.ndarray)
Speed_rpm = NewType('speed_rpm', float)


class FEEMSResult(NamedTuple):
    fuel_consumption_total_kg: float
    hydrogen_consumption_total_kg: float = None
    energy_consumption_electric_total_MJ: float = None
    energy_consumption_mechanical_total_MJ: float = None
    running_hours_main_engines_hr: float = None
    running_hours_genset_total_hr: float = None
    running_hours_fuel_cell_total_hr: float = None
    running_hours_pti_pto_total_hr: float = None
    co2_emission_total_kg: float = None
    nox_emission_total_kg: float = None
    detail_result: pd.DataFrame = None


@unique
class TypeFuel(Enum):
    HFO = 0
    LSHFO = 1
    DIESEL = 2
    LNG = 3
    HYDROGEN = 4
    MULTIFUEL = 5
    OTHERS = 6


@unique
class TypeComponent(Enum):
    NONE = 0
    MAIN_ENGINE = 1
    AUXILIARY_ENGINE = 2
    GENERATOR = 3
    PROPULSION_DRIVE = 4
    OTHER_LOAD = 5
    PTI_PTO = 6
    BATTERY_SYSTEM = 7
    FUEL_CELL_SYSTEM = 8
    RECTIFIER = 9
    MAIN_ENGINE_WITH_GEARBOX = 10
    ELECTRIC_MOTOR = 11
    GENSET = 12
    TRANSFORMER = 13
    INVERTER = 14
    CIRCUIT_BREAKER = 15
    ACTIVE_FRONT_END = 16
    POWER_CONVERTER = 17
    SYNCHRONOUS_MACHINE = 18
    INDUCTION_MACHINE = 19
    GEARBOX = 20
    FUEL_CELL = 21
    PROPELLER_LOAD = 22
    OTHER_MECHANICAL_LOAD = 23
    BATTERY = 24
    SUPERCAPACITOR = 25
    SUPERCAPACITOR_SYSTEM = 26


@unique
class TypeNode(Enum):
    NONE = 0
    BUS_TIE_BREAKER = 1
    SWITCHBOARD = 2
    BUS = 3
    SHAFTLINE = 4


@unique
class TypePower(Enum):
    NONE = 0
    POWER_SOURCE = 1
    POWER_CONSUMER = 2
    PTI_PTO = 3
    ENERGY_STORAGE = 4
    POWER_TRANSMISSION = 5


@unique
class TypeValueBus(Enum):
    POWER_IN_BY_POWER_TYPE = 0
    POWER_OUT_BY_POWER_TYPE = 1
    LOAD_KW_SOURCES = 2
    POWER_AVAIL_POWER_SOURCES_SYMMETRIC = 3


@unique
class OperationModeForPTIPTO(Enum):
    FULL_PTO = 0
    PARTIAL_PTO = 1
    PARTIAL_PTI = 2
    FULL_PTI = 3
    INDEPENDENT = 4
