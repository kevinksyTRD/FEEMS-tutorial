from enum import unique, Enum
from operator import itemgetter
from typing import Union, List, Tuple, Dict, NewType

import numpy as np
import pandas as pd

from feems.components_model.component_electric import (ElectricComponent, Genset,
                                                                                       SerialSystemElectric, PTIPTO,
                                                                                       MechanicalComponent)
from feems.components_model.node import Switchboard, BusBreaker, ShaftLine, SwbId
from feems.components_model.utility import IntegrationMethod
from feems.exceptions import ConfigurationError

from feems.types_for_feems import FEEMSResult, TypePower, TypeComponent, TypeValueBus

BusId = NewType('BusId', int)




class ElectricPowerSystem:

    def __init__(
            self, name: str,
            power_plant_components: List[Union[ElectricComponent, Genset, SerialSystemElectric, PTIPTO]],
            bus_tie_connections: List[Tuple[SwbId, SwbId]]
    ):
        component2switchboard: List[SwbId] = []
        power_source2switchboard: List[SwbId] = []
        self.name = name
        self.power_sources: List[Union[ElectricComponent, Genset, SerialSystemElectric]] = []
        self.propulsion_drives: List[Union[ElectricComponent, SerialSystemElectric]] = []
        self.pti_pto: List[PTIPTO] = []
        self.energy_storage: List[Union[ElectricComponent, SerialSystemElectric]] = []
        self.other_load: List[Union[ElectricComponent, SerialSystemElectric]] = []
        self.switchboards: Dict[SwbId, Switchboard] = {}
        self.bus_tie_breakers: List[BusBreaker] = []
        self.no_bus: List[int] = []
        self.switchboard2bus: List[Dict[SwbId, BusId]] = []
        self.bus_tie_status_system: List[np.ndarray] = []
        self.bus_configuration_change_index: List = [0]
        #: Categorize the components
        for component in power_plant_components:
            if component.power_type == TypePower.POWER_SOURCE:
                self.power_sources.append(component)
                power_source2switchboard.append(component.switchboard_id)
                component2switchboard.append(component.switchboard_id)
            elif component.type == TypeComponent.PROPULSION_DRIVE:
                self.propulsion_drives.append(component)
                component2switchboard.append(component.switchboard_id)
            elif component.type == TypeComponent.PTI_PTO:
                self.pti_pto.append(component)
                component2switchboard.append(component.switchboard_id)
            elif component.power_type == TypePower.ENERGY_STORAGE:
                self.energy_storage.append(component)
                component2switchboard.append(component.switchboard_id)
            elif component.power_type == TypePower.POWER_CONSUMER:
                self.other_load.append(component)
                component2switchboard.append(component.switchboard_id)

        #: Create a list of Switchboard objects based on the switchboard information given
        switchboard_id_from_power_sources = list(dict.fromkeys(power_source2switchboard).keys())
        switchboard_id_from_power_sources.sort()
        self.switchboard_id: List[SwbId] = list(dict.fromkeys(component2switchboard).keys())
        self.switchboard_id.sort()
        if self.switchboard_id != switchboard_id_from_power_sources:
            raise ValueError("There is a component that has a switchboard id that has no power source")
        for s in self.switchboard_id:
            if isinstance(s, int) and s <= 0:
                raise ValueError("The switchboard id should be a positive integer, it is: %s" % s)
        self.switchboard_id.sort()
        for swb_id in self.switchboard_id:
            comp_idx = np.arange(0, len(power_plant_components))[np.array(component2switchboard) == swb_id].tolist()
            comp_by_swb_id = itemgetter(*comp_idx)(power_plant_components)
            if type(comp_by_swb_id) is tuple:
                comp_by_swb_id = list(comp_by_swb_id)
            else:
                comp_by_swb_id = [comp_by_swb_id]
            self.switchboards[swb_id] = Switchboard('switchboard{:d}'.format(swb_id), swb_id, comp_by_swb_id)

        #: Assign the switchboards to the breaker
        self.no_bus_tie_breakers = len(bus_tie_connections)
        self.bus_tie_breakers: List[BusBreaker] = []
        for i, connection in enumerate(bus_tie_connections):
            self.bus_tie_breakers.append(
                BusBreaker(
                    name='bus breaker {}'.format(i + 1), switchboard_ids=connection,
                    switchboards=[self.switchboards[connection[0]], self.switchboards[connection[1]]]
                )
            )
        self.no_power_sources = len(self.power_sources)
        self.no_propulsion_units = len(self.propulsion_drives)
        self.no_energy_storage = len(self.energy_storage)
        self.no_pti_pto = len(self.pti_pto)
        self.no_other_load = len(self.other_load)
        self.no_switchboard = len(self.switchboards)

    def set_status_by_switchboard_id_power_type(
            self, switchboard_id: SwbId, power_type: TypePower, status: np.ndarray
    ):
        self.switchboards[switchboard_id].set_status_components_by_power_type(type_=power_type, status=status)

    def set_load_sharing_mode_power_sources_by_switchboard_id_power_type(
            self, switchboard_id: SwbId, power_type: TypePower, load_sharing_mode: np.ndarray
    ):
        self.switchboards[switchboard_id].set_load_sharing_mode_components_by_power_type(
            type_=power_type, load_sharing_mode=load_sharing_mode
        )

    def set_power_input_from_power_output_by_switchboard_id_type_name(
            self, power_output: np.ndarray, switchboard_id: SwbId, type_: TypePower, name: str
    ):
        """Set power input from power output for the component specified by its switchboard id, type and name

        :param power_output: Power output of the component, 1d array of float
        :param switchboard_id: Switchboard number that the component is connected to
        :param type_: Type of the component as specified by TypePower class
        :param name: Name of the component
        :return: 1 for success, 0 for error
        """
        return self.switchboards[switchboard_id].set_power_load_component_from_power_output_by_type_and_name(
            name=name, power_type=type_, power_output=power_output
        )

    def set_bus_tie_status_all(self, bus_tie_status: np.ndarray):
        for i, bus_tie_breaker in enumerate(self.bus_tie_breakers):
            bus_tie_breaker.status = bus_tie_status[:, i]
        self.switchboard2bus_configuration()

    def set_bus_tie_status(self, bus_ties_status: List[Tuple[int, np.ndarray]]):
        length_status = len(bus_ties_status[0][1])
        for bus_tie_status in bus_ties_status:
            if length_status != len(bus_tie_status[1]):
                raise (IndexError, "The length of the status values for bus tie breakers is not "
                                   "identical for no. {} breaker".format(bus_tie_status[0]))
            self.bus_tie_breakers[bus_tie_status[0] - 1].status = bus_tie_status[1]
        self.switchboard2bus_configuration()

    def get_bus_tie_status(self) -> List[np.ndarray]:
        if len(self.bus_tie_breakers) == 0:
            return []

        length_status = len(self.bus_tie_breakers[0].status)
        bus_tie_status = []
        for i, bus_tie_breaker in enumerate(self.bus_tie_breakers):
            if length_status != len(bus_tie_breaker.status):
                raise IndexError("The length of the status values for bus tie breakers is not "
                                   "identical for no. {} breaker".format(i + 1))
            bus_tie_status.append(bus_tie_breaker.status)
        return bus_tie_status

    def switchboard2bus_configuration(self):
        bus_tie_status_list = self.get_bus_tie_status()
        bus_tie_status_array = np.array(bus_tie_status_list)
        self.no_bus: List[int] = []
        self.switchboard2bus = []
        self.bus_tie_status_system = []
        self.bus_configuration_change_index = [0]

        if len(self.bus_tie_breakers) == 0:
            self.no_bus.append(1)
            assert len(self.switchboards) == 1
            swb_id = None
            for _, swb in self.switchboards.items():
                swb_id = swb.id
                break
            assert swb_id is not None
            bus_id = BusId(swb_id)
            self.switchboard2bus.append({swb_id: bus_id})
            return

        #: Find the index when the bus configuration changes
        bus_tie_diff = np.any(np.diff(bus_tie_status_array, axis=1), axis=0)
        index = np.concatenate((np.array([True]), bus_tie_diff))
        self.bus_tie_status_system = [
            bus_tie_status[index] for bus_tie_status in bus_tie_status_list
        ]
        self.bus_configuration_change_index = np.arange(0, len(index))[index].tolist()

        #: Find the number of logical buses and mapping for switchboard to bus
        for i in range(len(self.bus_tie_status_system[0])):
            bus_config_status = [
                self.bus_tie_status_system[j][i] for j, bus_tie_breaker in enumerate(self.bus_tie_breakers)
            ]
            switchboard2bus: Dict[SwbId, BusId] = {}
            for busId, swbId in enumerate(self.switchboard_id):
                switchboard2bus[swbId] = BusId(busId)
            merge_buses: Dict[BusId, BusId] = {}
            for j, closed in enumerate(bus_config_status):
                if closed:
                    bus1 = switchboard2bus[self.bus_tie_breakers[j].switchboard_ids[0]]
                    bus2 = switchboard2bus[self.bus_tie_breakers[j].switchboard_ids[1]]
                    if bus1 in merge_buses and bus2 in merge_buses:
                        raise NotImplementedError("this case is not implemented")
                    elif bus1 in merge_buses:
                        new_bus_id = merge_buses[bus1]
                        merge_buses[bus2] = new_bus_id
                    elif bus2 in merge_buses:
                        new_bus_id = merge_buses[bus2]
                        merge_buses[bus1] = new_bus_id
                    else:
                        new_bus_id = bus1
                        merge_buses[bus2] = new_bus_id

            no_bus = 0
            for idx, old_bus_id in switchboard2bus.items():
                if old_bus_id in merge_buses:
                    new_bus_id = merge_buses[old_bus_id]
                    switchboard2bus[idx] = new_bus_id
                else:
                    no_bus += 1

            # Rename so that the numbers are consecutive:
            bus_ids = []
            for _, bus in switchboard2bus.items():
                if bus not in bus_ids:
                    bus_ids.append(bus)
            new_bus_ids = {}
            for new, old in enumerate(bus_ids):
                new_bus_ids[old] = BusId(new + 1)

            for swb_id, bus_id in switchboard2bus.items():
                switchboard2bus[swb_id] = new_bus_ids[bus_id]

            self.no_bus.append(no_bus)
            self.switchboard2bus.append(switchboard2bus)

    @property
    def no_bus_configuration_change(self) -> int:
        return len(self.no_bus)

    def get_sum_power_out_rated_buses_by_power_type(self, type_: TypePower) -> Dict[BusId, np.ndarray]:
        sum_power_out_rated_switchboards = {}
        for swb_id, switchboard in self.switchboards.items():
            sum_power_out_rated_switchboards[swb_id] = (
                np.array(switchboard.get_power_rated_component_by_power_type(type_)).sum()
            )
        sum_power_out_rated_bus = {}
        for swb_id, _ in enumerate(self.switchboards):
            sum_power_out_rated_bus[BusId(swb_id + 1)] = np.zeros(self.no_bus_configuration_change)
        for i, switchboard2bus in enumerate(self.switchboard2bus):
            for swb_id, bus_id in switchboard2bus.items():
                sum_power_out_rated_bus[bus_id][i] += sum_power_out_rated_switchboards[swb_id]
        return sum_power_out_rated_bus

    def _get_sum_buses(
            self, which_value: TypeValueBus, power_type: TypePower = TypePower.POWER_CONSUMER
    ) -> Dict[BusId, np.ndarray]:
        sum_switchboards = {}
        len_sum = []
        for _, switchboard in self.switchboards.items():
            if switchboard.component_by_power_type[power_type.value]:
                if which_value == TypeValueBus.POWER_IN_BY_POWER_TYPE:
                    sum_temp = switchboard.get_sum_power_input_by_power_type(power_type)
                elif which_value == TypeValueBus.POWER_OUT_BY_POWER_TYPE:
                    sum_temp = switchboard.get_sum_power_output_by_power_type(power_type)
                elif which_value == TypeValueBus.LOAD_KW_SOURCES:
                    sum_temp = switchboard.get_sum_load_kw_sources_symmetric()
                elif which_value == TypeValueBus.POWER_AVAIL_POWER_SOURCES_SYMMETRIC:
                    sum_temp = switchboard.get_sum_power_avail_for_power_sources_symmetric()
                else:
                    raise TypeError("The value name specified is not valid")
                sum_switchboards[switchboard.id] = sum_temp
                len_sum.append(len(sum_temp))
        if not sum_switchboards:
            sum_buses = {}
            for i in range(self.no_switchboard):
                sum_buses[BusId(i + 1)] = np.zeros(1)
            return sum_buses
        assert len(set(len_sum)) == 1, "The length of the sum of values ({}) of the switchboards is " \
                                       "are not identical to each other.".format(which_value.name)
        no_points = len_sum[0]
        sum_buses = {}
        for i in range(self.no_switchboard):
            sum_buses[BusId(i + 1)] = np.zeros(no_points)
        for i in range(self.no_bus_configuration_change):
            index_start = self.bus_configuration_change_index[i]

            if i + 1 == self.no_bus_configuration_change:
                index_end = no_points
            else:
                index_end = self.bus_configuration_change_index[i + 1]

            for swb_id, bus_id in self.switchboard2bus[i].items():
                if self.switchboards[swb_id].component_by_power_type[power_type.value]:
                    sum_buses[bus_id][index_start:index_end] += \
                        sum_switchboards[swb_id][index_start:index_end]
        return sum_buses

    def get_sum_power_in_buses_by_power_type(self, type_: TypePower) -> Dict[BusId, np.ndarray]:
        return self._get_sum_buses(TypeValueBus.POWER_IN_BY_POWER_TYPE, power_type=type_)

    def get_sum_power_output_buses_by_power_type(self, type_: TypePower) -> Dict[BusId, np.ndarray]:
        return self._get_sum_buses(TypeValueBus.POWER_OUT_BY_POWER_TYPE, power_type=type_)

    def get_sum_load_kw_sources_symmetric_buses(self) -> Dict[BusId, np.ndarray]:
        return self._get_sum_buses(TypeValueBus.LOAD_KW_SOURCES, power_type=TypePower.POWER_SOURCE)

    def get_sum_power_avail_power_sources_symmetric_buses(self) -> Dict[BusId, np.ndarray]:
        return self._get_sum_buses(TypeValueBus.POWER_AVAIL_POWER_SOURCES_SYMMETRIC, power_type=TypePower.POWER_SOURCE)

    def do_power_balance_calculation(self):
        """
        Calculate the power output of the gensets and power sources (PTI/PTO or energy storage device at
        symmetric load sharing mode) based on the power balance.
        """
        sum_load_kw_sources_symmetric_buses = self.get_sum_load_kw_sources_symmetric_buses()
        sum_power_avail_power_sources_symmetric_buses = self.get_sum_power_avail_power_sources_symmetric_buses()
        load_buses: Dict[BusId, np.ndarray] = {}
        for bus_id in sum_load_kw_sources_symmetric_buses:
            sum_load = sum_load_kw_sources_symmetric_buses[bus_id]
            sum_power_avail = sum_power_avail_power_sources_symmetric_buses[bus_id]
            no_points = sum_load.shape[0]
            index_non_zero = sum_load != 0
            load_buses[bus_id] = np.zeros(shape=sum_load.shape)
            load_buses[bus_id][index_non_zero] = sum_load[index_non_zero] / sum_power_avail[index_non_zero]
        for _, switchboard in self.switchboards.items():
            load_switchboard_symmetric_power_source = np.zeros(no_points)
            for i, switchboard2bus in enumerate(self.switchboard2bus):
                index_start = self.bus_configuration_change_index[i]
                index_end = self.bus_configuration_change_index[i + 1] if i + 1 < self.no_bus_configuration_change \
                    else no_points
                bus_id = switchboard2bus[switchboard.id]
                load_switchboard_symmetric_power_source[index_start:index_end] = \
                    load_buses[bus_id][index_start:index_end]
            switchboard.set_power_out_power_sources(load_switchboard_symmetric_power_source)

    def get_fuel_energy_consumption_running_time(
            self, time_interval_s: Union[float, np.ndarray],
            nox_emission_criteria: int = 2,
            integration_method: IntegrationMethod = IntegrationMethod.simpson,
        ) -> FEEMSResult:
        """
        Get the performance result of the power calculation. Prerequisite:
          - setting load on the power consumers,
          - setting status (on/off) of the power consumers, pti_pto, energy storage devices,
          - setting the load sharing status (0 for symmetric load sharing, 0~1 for specific power) of the power
            consumers, pti_pto, energy storage devices
          - setting power input to the power sources with asymmetric load sharing
          - doing power balance calculation

        :param nox_emission_criteria: IMO NOx emission tier 1, 2, 3
        :param time_interval_s: the time interval for input load series in seconds
        :param integration_method: Integration method, "simpson" or "trapezoid"
        :return: fuel_consumption(kg),
                hydrogen_consumption(kg)
                energy_consumption_electric(MJ): Net electric energy consumption, only relevant for energy storage
                energy_consumption_mechanical(MJ): Net mechanical energy consumption, only relevant for pti_pti or
                    generators, if applicable
                running_time_genset(s): Running time for genset
                running_time_fuel_cell(s): Running time for fuel cell
                running_time_pti_pto(s): Running time for pti_pto
                co2_emission(kg)
                nox_emission(kg)
                result: DataFrame that contains the detail for each machinery
        """
        fuel_consumption = 0
        hydrogen_consumption = 0
        energy_consumption_electric = 0
        energy_consumption_mechanical = 0
        running_time_genset = 0
        running_time_fuel_cell = 0
        running_time_pti_pto = 0
        co2_emission_total_kg = 0
        nox_emission_total_kg = 0
        detail_result = pd.DataFrame()
        for _,  switchboard in self.switchboards.items():
            result_swb: FEEMSResult = switchboard.get_fuel_energy_consumption_running_time(
                time_interval_s, nox_emission_criteria, integration_method
            )
            detail_result_swb = result_swb.detail_result
            detail_result_swb['switchboard id'] = switchboard.id
            detail_result = detail_result.append(detail_result_swb)
            fuel_consumption += result_swb.fuel_consumption_total_kg
            hydrogen_consumption += result_swb.hydrogen_consumption_total_kg
            energy_consumption_mechanical += result_swb.energy_consumption_mechanical_total_MJ
            energy_consumption_electric += result_swb.energy_consumption_electric_total_MJ
            running_time_genset += result_swb.running_hours_genset_total_hr
            running_time_fuel_cell += result_swb.running_hours_fuel_cell_total_hr
            running_time_pti_pto += result_swb.running_hours_pti_pto_total_hr
            co2_emission_total_kg += result_swb.co2_emission_total_kg
            nox_emission_total_kg += result_swb.nox_emission_total_kg

        return FEEMSResult(
            fuel_consumption_total_kg=fuel_consumption,
            hydrogen_consumption_total_kg=hydrogen_consumption,
            energy_consumption_mechanical_total_MJ=energy_consumption_mechanical,
            energy_consumption_electric_total_MJ=energy_consumption_electric,
            running_hours_genset_total_hr=running_time_genset,
            running_hours_fuel_cell_total_hr=running_time_fuel_cell,
            running_hours_pti_pto_total_hr=running_time_pti_pto,
            co2_emission_total_kg=co2_emission_total_kg,
            nox_emission_total_kg=nox_emission_total_kg,
            detail_result=detail_result
        )


class MechanicalPropulsionSystem:
    """
    System configuration for mechanical / hybrid propulsion. One should provide its name,
    and components for initialization to create an instance. The components should include
    at least one of each following category.
    - Main engine: Required. At least one per shaftline. Power source of the mechanical
    propulsion. Use MainEngineForMechanicalPropulsion instance. If it is connected to gearbox,
    it is recommended to set the gearbox together as a serial system component.
    Use MainEngineWithGearBoxForMechanicalPropulsion in that case.
    - PTI_PTO: Optional. Only one per shaftline allowed. Use PTIPTO class to create an instance.
    - Mechanical loads: Required. At least one per shaftline. Use MechanicalPropulsionComponent.
    """

    def __init__(
            self,
            name: str,
            components_list: List[MechanicalComponent]
    ):
        self.name = name
        self.main_engines = []
        self.pti_ptos = []
        self.mechanical_loads = []
        self.shaft_line: List[ShaftLine] = []
        self.component_by_shaft_line_id = {}
        #: Collect the components in the category and collect shaft line ids.
        for component in components_list:
            if component.shaft_line_id not in self.component_by_shaft_line_id.keys():
                self.component_by_shaft_line_id[component.shaft_line_id] = [component]
            else:
                self.component_by_shaft_line_id[component.shaft_line_id].append(component)
            if component.type in [TypeComponent.MAIN_ENGINE, TypeComponent.MAIN_ENGINE_WITH_GEARBOX]:
                self.main_engines.append(component)
            elif component.type == TypeComponent.PTI_PTO:
                self.pti_ptos.append(component)
            else:
                self.mechanical_loads.append(component)

        #: make a sorted, unique list of shaft line id.
        self.shaft_line_id = list(self.component_by_shaft_line_id.keys())
        self.shaft_line_id.sort()

        #: Count the number of components / shaft lines
        self.no_shaft_lines = len(self.shaft_line_id)
        self.no_main_engines = len(self.main_engines)
        self.no_pti_ptos = len(self.pti_ptos)
        self.no_mechanical_loads = len(self.mechanical_loads)

        #: Create a shaft line instances
        for id_num in self.shaft_line_id:
            self.shaft_line.append(
                ShaftLine(
                    'shaft line %i' % id_num,
                    id_num,
                    self.component_by_shaft_line_id[id_num]
                )
            )

    def get_component_by_name_shaft_line_id_power_type(self, name: str, shaft_line_id: int,
                                                       power_type: TypePower) -> MechanicalComponent:
        index_shaft_line = self.shaft_line_id.index(shaft_line_id)
        return self.shaft_line[index_shaft_line].get_component_by_name_power_type(name, power_type)

    def set_power_consumer_load_by_value_for_given_name_shaft_line_id(
            self, name: str, shaft_line_id: int, power_input: np.ndarray
    ) -> Union[int, None]:
        """
        Set power load (power input) of the power consumer directly by values
        for the given name and the shaft line id.
        :param name: The name of the component
        :param shaft_line_id: The id of the shaft line
        :param power_input: ndarrady of power input value in kW
        :return: 1 for success, None for error
        """
        component = self.get_component_by_name_shaft_line_id_power_type(
            name, shaft_line_id, TypePower.POWER_CONSUMER
        )
        if component:
            component.set_power_output_from_input(power_input)
            return 1
        else:
            return None

    def set_power_consumer_load_by_power_output_for_given_name_shaft_line_id(
            self, name: str, shaft_line_id: int, power_output: np.ndarray
    ) -> Union[int, None]:
        """
        Set power load (power input) of the power consumer by giving the power output
        for the given name and the shaft line id.
        :param name: The name of the component
        :param shaft_line_id: The id of the shaft line
        :param power_input: ndarrady of power input value in kW
        :return: 1 for success, None for error
        """
        component = self.get_component_by_name_shaft_line_id_power_type(
            name, shaft_line_id, TypePower.POWER_CONSUMER
        )
        if component:
            component.set_power_input_from_output(power_output)
            return 1
        else:
            return None

    def set_full_pti_mode_for_name_shaft_line_id(
            self, name: str, shaft_line_id: int, full_pti_pto_mode: np.ndarray
    ) -> Union[int, None]:
        """
        Set full PTI mode for the PTI/PTO (True: full PTI mode, False: otherwise)
        :param name: name of the PTI/PTO
        :param shaft_line_id: shaft line id for the PTI/PTO
        :param full_pti_pto_mode: ndarray of boolean
        :return: 1 for success, None for error
        """
        pti_pto = self.get_component_by_name_shaft_line_id_power_type(name, shaft_line_id, TypePower.PTI_PTO)
        if pti_pto:
            pti_pto.full_pti_mode = full_pti_pto_mode
            return 1
        else:
            return None

    def set_power_input_pti_pto_by_value_for_name_shaft_line_id(
            self, name: str, shaft_line_id: int, power_input: np.ndarray
    ) -> Union[int, None]:
        """
        Set power input / output for the PTI/PTO by the given power input
        :param name: name of the PTI/PTO
        :param shaft_line_id: shaft line id for the PTI/PTO
        :param power_input: ndarray of power output value in kW
        :return: 1 for success, None for error
        """
        pti_pto = self.get_component_by_name_shaft_line_id_power_type(name, shaft_line_id, TypePower.PTI_PTO)
        if pti_pto:
            pti_pto.set_power_output_from_input(power_input)
            return 1
        else:
            return None

    def set_power_input_pti_pto_by_power_output_value_for_name_shaft_line_id(
            self, name: str, shaft_line_id: int, power_output: np.ndarray
    ) -> Union[int, None]:
        """
        Set power input / output for the PTI/PTO by the given power output
        :param name: name of the PTI/PTO
        :param shaft_line_id: shaft line id for the PTI/PTO
        :param power_output: ndarray of power output value in kW
        :return: 1 for success, None for error
        """
        pti_pto = self.get_component_by_name_shaft_line_id_power_type(name, shaft_line_id, TypePower.PTI_PTO)
        if pti_pto:
            pti_pto.set_power_input_from_output(power_output)
            return 1
        else:
            return None

    def set_status_main_engine_for_name_shaft_line_id(
            self, name: str, shaft_line_id: int, status: np.ndarray
    ) -> Union[int, None]:
        """
        Set status for the main engine (True: on, False: off)
        :param name: name of the main engine
        :param shaft_line_id: shaft line id for the main engine
        :param status: array of status of the engine status (boolean)
        :return: 1 for success, None for error
        """
        engine = self.get_component_by_name_shaft_line_id_power_type(name, shaft_line_id, TypePower.POWER_SOURCE)
        if engine:
            engine.status = status
            return 1
        return None

    def do_power_balance(self):
        """
        Perform power balance calculation, determining the main engine outputs.
        Pre-requisite:
          - All the loads on the power consumers have been set
          - PTI/PTO power input/output has been set from the electrical power balance, if relevant
          - Set Full PTI mode if applicable
        In some cases, the power balance calculation has to be done at least two times if there is
        any case of full PTI mode. In the full PTI mode, it is the PTI that balances the mechanical
        loads on the shaft lines. Therefore, the PTI power input is the output of this mechanical
        power balance calculation which is input to the power balance calculation of the electric
        system. The recommendation is
          - to perform electric power balance to get the power output of the pto.
          - then to perform mechanical power balance calculation which will change the power input/output
            in case of full PTI mode
          - finally to perform electric power balance again with the updated power input of the PTI/PTO
        """
        for shaft_line in self.shaft_line:
            shaft_line.do_power_balance()

    def get_fuel_consumption_running_hours(
            self,
            time_step: float,
            nox_emission_criteria: int = 2,
            integration_method: str = 'simpson'
    ) -> FEEMSResult:
        """
        Calculates fuel consumption and running hours of main engines
        :param nox_emission_criteria: IMO NOx tier 1, 2, 3
        :param time_step: Time step for the discrete values
        :param integration_method: numerical integration method('simpson' or 'trapezoid')
        :return: FEEMSResult with fuel_consumption[kg], mechanical energy consumption[MJ], main engine running hours,
            CO2 emission[kg], NOx emission[kg], detail
        """
        detail_result = pd.DataFrame()
        for i, shaft_line in enumerate(self.shaft_line):
            result_shaft_line: FEEMSResult = shaft_line.get_fuel_calculation_running_hours(
                time_step=time_step, nox_emission_criteria=nox_emission_criteria,
                integration_method=integration_method
            )
            detail_result = detail_result.append(result_shaft_line.detail_result)

        result = FEEMSResult(
            fuel_consumption_total_kg=detail_result.iloc[:, 0].sum(),
            energy_consumption_mechanical_total_MJ=detail_result.iloc[:, 1].sum(),
            running_hours_main_engines_hr=detail_result.iloc[:, 2].sum(),
            co2_emission_total_kg=detail_result.iloc[:, 3].sum(),
            nox_emission_total_kg=detail_result.iloc[:, 4].sum(),
            detail_result=detail_result
        )

        return result


class HybridPropulsionSystem:

    def __init__(
            self,
            name: str,
            electric_system: ElectricPowerSystem,
            mechanical_system: MechanicalPropulsionSystem
    ):
        self.name = name
        self.electric_system = electric_system
        self.mechanical_system = mechanical_system

        #: Check if PTI/PTO machine exists and if it is the same component instance for both
        #: electric and mechanical system
        self._check_configuration()

    def _check_configuration(self):
        try:
            assert (self.electric_system.no_pti_pto > 0)
        except AssertionError:
            raise (ConfigurationError, 'PTI/PTO is not configured for the electric system.')
        try:
            assert (self.mechanical_system.no_pti_ptos > 0)
        except AssertionError:
            raise (ConfigurationError, 'PTI/PTO is not configured for the mechanical system.')
        try:
            assert (self.electric_system.no_pti_pto == self.mechanical_system.no_pti_ptos)
        except AssertionError:
            raise (ConfigurationError, 'Number of PTI/PTO for electric system does not match the mechanical.')
        try:
            for pti_pto in self.electric_system.pti_pto:
                assert (pti_pto in self.mechanical_system.pti_ptos)
        except AssertionError:
            msg = 'One of the PTI/PTOs configured for electric system ' \
                  'does not match the ones in the mechanical system'
            raise (ConfigurationError, msg)

    def do_power_balance(self):
        """
        Perform power balance calculation, determining the power output of all the power sources
        Pre-requisite:
          - All the loads on the power consumers have been set (Mechanical / Electrical)
          - PTI/PTO power input/output has been set from the electrical power balance, if applicable
          - Set Full PTI mode if applicable
        The power balance calculation has to be done two times if there is
        any case of full PTI mode. In the full PTI mode, it is the PTI that balances the mechanical
        loads on the shaft lines. Therefore, the PTI power input is the output of this mechanical
        power balance calculation which becomes input to the power balance calculation of the electric
        system. The recommendation is
          - to perform electric power balance to get the power output of the pto.
          - then to perform mechanical power balance calculation which will change the power input/output
            in case of full PTI mode
          - finally to perform electric power balance again with the updated power input of the PTI/PTO
        """
        self.electric_system.do_power_balance_calculation()
        self.mechanical_system.do_power_balance()

        #: Check for full PTI mode and repeat power balance calculation for electric system if full PTI mode is found
        full_pti_pto_mode_exists = False
        for pti_pto in self.electric_system.pti_pto:
            full_pti_pto_mode_exists |= any(pti_pto.full_pti_mode)
        if full_pti_pto_mode_exists:
            self.electric_system.do_power_balance_calculation()
