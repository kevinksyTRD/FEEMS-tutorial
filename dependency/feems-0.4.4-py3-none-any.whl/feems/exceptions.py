class ConfigurationError(Exception):
    pass


class PowerBalanceError(Exception):
    pass


class InputError(Exception):
    pass
