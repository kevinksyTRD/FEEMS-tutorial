import random
from unittest import TestCase

import numpy as np

from feems.components_model import Engine, ElectricMachine, Genset, ElectricComponent
from feems.components_model.utility import IntegrationMethod
from feems.system_model import ElectricPowerSystem
from feems.types_for_feems import TypeComponent, Power_kW, Speed_rpm, TypePower

random.seed(10)


class TestElectricPowerSystem(TestCase):

    def __init__(self, *args, **kwargs):
        """
        Initialize with configuration for conventional, hybrid and diesel electric propulsion and power system variants.
        """
        super().__init__(*args, **kwargs)

        #: main engine and gearbox
        rated_power_aux_engine = Power_kW(1000)
        rated_speed_genset = Speed_rpm(1500)
        bsfc_curve = np.array([[1.00, .75, .50, .25, .10], [193.66, 188.995, 194.47, 211.4, 250]]).transpose()
        aux_engine_object = Engine(
            type_=TypeComponent.MAIN_ENGINE, name='main engine', rated_power=Power_kW(rated_power_aux_engine),
            rated_speed=Speed_rpm(rated_speed_genset), bsfc_curve=bsfc_curve
        )

        efficiency_generator = .5
        self.switchboard_id = 1
        self.generator = ElectricMachine(type_=TypeComponent.GENERATOR, name="generator", rated_power=Power_kW(1),
                                         rated_speed=rated_speed_genset,
                                         power_type=TypePower.POWER_SOURCE, switchboard_id=self.switchboard_id,
                                         eff_curve=np.array([efficiency_generator]))
        genset = Genset(name="genset", aux_engine=aux_engine_object, generator=self.generator)

        #: Other load
        self.rated_power_other_load = Power_kW(1000)
        self.other_load = ElectricComponent(
            type_=TypeComponent.OTHER_LOAD, name='other loads', power_type=TypePower.POWER_CONSUMER,
            rated_power=self.rated_power_other_load, rated_speed=Speed_rpm(0),
            eff_curve=np.array([1]), switchboard_id=self.switchboard_id
        )

        #: Bus tie configuration
        bus_tie = []

        #: Configure the system
        self.power_system = ElectricPowerSystem(
            name='diesel electric system',
            power_plant_components=[genset, self.other_load],
            bus_tie_connections=bus_tie
        )

    def test_power_balance_calculation(self):
        # Sets the load
        load_other = np.array([.5, .5, .5]) * self.rated_power_other_load
        duration = np.array([1, 3, 2])
        self.other_load.set_power_input_from_output(load_other)
        # Set the generators to always on
        gensets_on = np.ones(shape=[len(load_other), 1])
        self.power_system.set_status_by_switchboard_id_power_type(
            switchboard_id=self.switchboard_id, power_type=TypePower.POWER_SOURCE, status=gensets_on
        )
        # Sets the load sharing mode to equal sharing
        load_sharing_mode = np.zeros(shape=[len(load_other), 1])
        self.power_system.set_load_sharing_mode_power_sources_by_switchboard_id_power_type(
            switchboard_id=self.switchboard_id, power_type=TypePower.POWER_SOURCE, load_sharing_mode=load_sharing_mode)

        self.power_system.set_bus_tie_status_all(np.array([]))
        self.power_system.do_power_balance_calculation()
        bsfc = 193.66
        dt = duration.sum() / 3600
        power_other = load_other[0]
        efficiency_generator = self.generator.get_efficiency_from_load_percentage(
            power_other / self.generator.rated_power)

        fc_g = bsfc * power_other / efficiency_generator * dt
        fc_kg = fc_g / 1000
        res = self.power_system.get_fuel_energy_consumption_running_time(
            time_interval_s=duration,
            integration_method=IntegrationMethod.sum_with_time
        )
        self.assertAlmostEqual(fc_kg, res.fuel_consumption_total_kg)
