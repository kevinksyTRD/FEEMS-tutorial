import os
import random
from typing import Union
from unittest import TestCase

import numpy as np
import pandas as pd
from scipy.integrate import simps
from scipy.interpolate import PchipInterpolator

from feems.components_model.component_base import BasicComponent, SerialSystem
from feems.components_model.component_electric import (ElectricMachine,
                                                       ElectricComponent, PTIPTO,
                                                       Genset, FuelCellSystem,
                                                       SerialSystemElectric)
from feems.components_model.component_mechanical import (Engine,
                                                         MainEngineWithGearBoxForMechanicalPropulsion,
                                                         MechanicalPropulsionComponent)
from feems.components_model.node import Node, ShaftLine
from feems.components_model.utility import (get_efficiency_curve_from_points,
                                            get_efficiency_curve_from_dataframe,
                                            get_list_random_distribution_numbers_for_total_number)
from feems.types_for_feems import (TypeNode, TypeComponent, TypePower)
from test_for_fuel_calculation_for_machinery_system.utility import (create_components,
                                                                    create_random_monotonic_eff_curve,
                                                                    create_basic_components,
                                                                    create_dataframe_save_and_return,
                                                                    create_engine_component, electric_machine_eff_curve,
                                                                    create_switchboard_with_components,
                                                                    set_random_power_input_consumer_pti_pto_energy_storage,
                                                                    create_a_pti_pto,
                                                                    create_electric_components_for_switchboard)


class TestComponent(TestCase):

    def __init__(self, *args, **kwargs):
        super(TestComponent, self).__init__(*args, **kwargs)
        load = np.array([1.00, .75, .50, .25])
        eff = np.array([.9585018015, .9595580564, .9533974336, .9298900684])
        self.electric_machine_eff_curve = np.array([load, eff]).transpose()
        self.converter_eff = np.array([[1.00, .75, .50, .25], [.98, .972, .97, .96]]).transpose()

    def test_component(self):
        name = 'component'
        component = create_components(name, 1, 1000, 1000)
        power = np.random.rand() * component.rated_power
        self.assertEqual(component.name, name)
        self.assertEqual(component.get_type_name(), component.type.name)
        self.assertEqual(component.get_load(power), power / component.rated_power)

    def test_get_efficiency_curve_from_points(self):
        eff_curve = create_random_monotonic_eff_curve()
        interp_function, curve = get_efficiency_curve_from_points(eff_curve)
        self.assertAlmostEqual(abs(eff_curve[:, 1] - interp_function(eff_curve[:, 0])).sum(), 0)
        eff = np.random.rand(1)
        interp_function, curve = get_efficiency_curve_from_points(eff)
        self.assertEqual(eff, interp_function(np.random.rand()))
        columns = []
        for l in eff_curve[:, 0].tolist():
            columns.append('efficiency @{}%'.format(l))
        df = pd.DataFrame(np.reshape(eff_curve[:, 1], (1, -1)), columns=columns)
        interp_function, curve = get_efficiency_curve_from_dataframe(df, 'effic')
        self.assertAlmostEqual((eff_curve[:, 1] - interp_function(eff_curve[:, 0])).sum(), 0)

    def test_node(self):
        name = 'node'
        type_ = TypeNode(np.ceil(np.random.rand() * (len(TypeNode.__members__) - 1)))
        components = create_components('component', 10, 1000, 1000)
        node = Node(name, type_, components)
        power_total = np.zeros(10)
        for component in components:
            component.power_input = np.random.rand(10) * component.rated_power
            power_total += component.power_input
        self.assertEqual(len(node.components), len(components))
        node.get_power_out()
        self.assertEqual((power_total - node.power_out).sum(), 0)

    def test_engine_bsfc_interpolation_with_points_input(self):
        #: Create an engine component with a arbitrary bsfc curve
        rated_power_max = 1000
        rated_speed_max = 1000
        bsfc_curve = bsfc_curve = np.append(
            np.reshape(np.arange(10, 101, 10), (-1, 1)), np.random.rand(10, 1) * 200, axis=1
        )
        eng = create_engine_component(
            'main engine 1', rated_power_max, rated_speed_max, bsfc_curve
        )
        #: Make the bsfc interpolation function anc compare with the component method
        interp_func = PchipInterpolator(bsfc_curve[:, 0], bsfc_curve[:, 1], extrapolate=True)
        self.assertEqual((bsfc_curve - eng.specific_fuel_consumption_points).sum(), 0)
        power = np.random.rand(4) * eng.rated_power
        load = eng.get_load(power)
        bsfc = interp_func(load)
        self.assertEqual((eng.specific_fuel_consumption_interp(load) - bsfc).sum(), 0)
        fuel_consumption = bsfc * power / 1000 / 3600
        fuel_consumption_comp, load_comp, bsfc_comp = eng.get_fuel_cons_load_bsfc_from_power_out_kw(power)
        self.assertEqual((fuel_consumption_comp - fuel_consumption).sum(), 0)
        self.assertEqual((load_comp - load).sum(), 0)
        self.assertEqual((bsfc_comp - bsfc).sum(), 0)

    def test_engine_bsfc_interpolation_with_a_single_point_input(self):
        #: Create an engine component with a arbitrary bsfc curve
        rated_power = 1000 * np.random.rand()
        rated_speed = 1000 * np.random.rand()
        bsfc_curve = np.random.rand(1) * 200
        eng = Engine(TypeComponent.MAIN_ENGINE, 'main engine 1', rated_power, rated_speed, bsfc_curve)
        self.assertEqual(eng.specific_fuel_consumption_interp(np.random.rand()), bsfc_curve[0])

    def test_engine_with_file_bsfc_curve(self):
        """
        Test the engine class with file input
        """
        #: Create a DataFrame and save it to csv
        name = 'engine1'
        filename = 'info.csv'
        columns = ['Rated Power', 'Rated Speed', 'BSFC @100%', 'BSFC @75%', 'BSFC @50%', 'BSFC @25%', 'BSFC @10%']
        df = create_dataframe_save_and_return(name, filename, columns)
        bsfc_function, bsfc = get_efficiency_curve_from_dataframe(df, 'BSFC')

        #: Create an engine object and test_for_fuel_calculation_for_machinery_system
        eng = Engine(TypeComponent.MAIN_ENGINE, file_name=filename)
        load_points = np.random.rand(5)
        self.assertAlmostEqual(eng.name, name)
        self.assertAlmostEqual(eng.rated_speed, df['Rated Speed'].values[0])
        self.assertAlmostEqual(eng.rated_power, df['Rated Power'].values[0])
        self.assertAlmostEqual((eng.specific_fuel_consumption_points - bsfc).sum(), 0)
        self.assertAlmostEqual((eng.specific_fuel_consumption_interp(load_points) - bsfc_function(load_points)).sum(),
                               0)
        os.unlink(filename)

    def test_engine_with_file_bsfc_point(self):
        #: Create a DataFrame and save it to csv
        name = 'engine1'
        filename = 'info.csv'
        columns = ['Rated Power', 'Rated Speed', 'BSFC']
        df = create_dataframe_save_and_return(name, filename, columns)
        bsfc_curve, bsfc = get_efficiency_curve_from_dataframe(df, 'BSFC')

        #: Create an engine object and test_for_fuel_calculation_for_machinery_system
        eng = Engine(type_=TypeComponent.MAIN_ENGINE, file_name=filename)
        load_point = np.random.rand(5)
        self.assertAlmostEqual((eng.specific_fuel_consumption_points - bsfc).sum(), 0)
        self.assertAlmostEqual((eng.specific_fuel_consumption_interp(load_point) - bsfc[0, 1]).sum(), 0)
        os.unlink(filename)

    def test_basic_component(self):
        #: efficiency curve fitting test_for_fuel_calculation_for_machinery_system
        name = 'basic_component'
        rated_power_max = 1000
        rated_speed_max = 500
        basic_component = create_basic_components(name, 1, rated_power_max, rated_speed_max)
        interp_func = PchipInterpolator(basic_component._efficiency_points[:, 0],
                                        basic_component._efficiency_points[:, 1], extrapolate=True)
        # self.assertAlmostEqual((eff_curve - basic_component._efficiency_points).sum(), 0)
        load_perc = np.random.rand(5)
        self.assertAlmostEqual(
            (basic_component.get_efficiency_from_load_percentage(load_perc) - interp_func(load_perc)).sum(), 0)

        #: test the power conversions, forward power
        no_of_pts_to_test = 100000
        power_output = (2 * np.random.rand(no_of_pts_to_test) - 1) * basic_component.rated_power
        power_input = np.zeros(len(power_output))
        load_perc = basic_component.get_load(power_output)
        idx_forward_power = power_output > 0
        idx_reverse_power = np.bitwise_not(idx_forward_power)
        power_input[idx_reverse_power] = power_output[idx_reverse_power]
        power_input[idx_forward_power] = \
            power_output[idx_forward_power] / \
            basic_component.get_efficiency_from_load_percentage(load_perc[idx_forward_power])
        power_output[idx_reverse_power] = \
            power_input[idx_reverse_power] / \
            basic_component.get_efficiency_from_load_percentage(load_perc[idx_reverse_power])
        power_input_comp, load_perc = \
            basic_component.get_power_input_from_bidirectional_output(power_output)
        self.assertAlmostEqual((np.abs(power_input_comp - power_input)).sum() / no_of_pts_to_test, 0, 2)
        power_output_comp, load_perc = basic_component.get_power_output_from_bidirectional_input(power_input)
        self.assertAlmostEqual((np.abs(power_output_comp - power_output)).sum() / no_of_pts_to_test, 0, 2)

        #: single point efficiency value test_for_fuel_calculation_for_machinery_system
        eff_curve = np.clip(np.random.rand(1), .01, 1)
        basic_component = BasicComponent(
            type_=TypeComponent.NONE, name=name,
            power_type=random.choice([power_type for power_type in TypePower]),
            rated_power=rated_power_max, eff_curve=eff_curve,
            rated_speed=rated_speed_max
        )
        self.assertEqual((np.abs(basic_component.get_efficiency_from_load_percentage(load_perc) - eff_curve[0])).sum(),
                         0)

    def test_electric_component(self):
        #: switchboard id assignment test_for_fuel_calculation_for_machinery_system
        rated_power_max = 1000
        rated_speed_max = 100
        no_components = 100
        switchboard_id_list = np.random.randint(1, 11, no_components)
        electric_components = []
        type_power_list = [type_power for type_power in TypePower]
        for switchboard_id in switchboard_id_list:
            electric_components += create_electric_components_for_switchboard(
                random.choice(type_power_list), 1, rated_power_max * random.random(),
                rated_speed_max, switchboard_id
            )
        self.assertTrue(
            np.array_equal(
                switchboard_id_list,
                np.array([electric_component.switchboard_id for electric_component in electric_components])
            )
        )

    def test_electric_machine(self):
        # Create a electric machine component as power source
        rated_power_max = 1000
        rated_speed_max = 1000
        rated_power = rated_power_max * (random.random() / 2 + 0.5)
        electric_machine = ElectricMachine(
            type_=TypeComponent.GENERATOR, name='generator', rated_power=rated_power,
            rated_speed=rated_speed_max * random.random(), power_type=TypePower.POWER_SOURCE,
            switchboard_id=1, eff_curve=electric_machine_eff_curve
        )
        # Test for power input from the shaft.
        number_of_point_to_test = 10000
        power_electric = (2 * np.random.rand(number_of_point_to_test) - 1) * electric_machine.rated_power
        power_shaft = power_electric.copy()
        idx_generator = power_electric >= 0
        idx_motor = np.bitwise_not(idx_generator)
        load = electric_machine.get_load(power_electric)
        efficiency = electric_machine.get_efficiency_from_load_percentage(load)
        power_shaft[idx_generator] = power_electric[idx_generator] / efficiency[idx_generator]
        power_electric[idx_motor] = power_shaft[idx_motor] / efficiency[idx_motor]
        # Test for power input from the mechanical side
        power_electric_pred, load_pred = electric_machine.get_electric_power_load_from_shaft_power(power_shaft)
        self.assertAlmostEqual((np.abs(power_electric_pred - power_electric)).sum() / number_of_point_to_test, 0, 1)
        self.assertAlmostEqual((np.abs(load - load_pred)).sum() / number_of_point_to_test, 0, 2)
        # Test for power input from the electric side
        power_shaft_pred, load_pred = electric_machine.get_shaft_power_load_from_electric_power(power_electric, True)
        self.assertAlmostEqual((np.abs(power_shaft - power_shaft_pred)).sum() / number_of_point_to_test, 0, 4)
        self.assertAlmostEqual((np.abs(load - load_pred)).sum() / number_of_point_to_test, 0, 2)

        # Test for power consumer and PTI/PTO
        rated_power = rated_power_max * (random.random() * 0.5 + 0.5)
        rated_speed = rated_speed_max * random.random()
        electric_machine = ElectricMachine(
            type_=TypeComponent.ELECTRIC_MOTOR, name='electric_motor', rated_power=rated_power,
            rated_speed=rated_speed, power_type=TypePower.POWER_CONSUMER, switchboard_id=1,
            eff_curve=electric_machine_eff_curve
        )
        # Test for power input from the shaft
        number_of_point_to_test = 10000
        power_shaft = (2 * np.random.rand(number_of_point_to_test) - 1) * electric_machine.rated_power
        power_electric = power_shaft.copy()
        load = electric_machine.get_load(power_electric)
        efficiency = electric_machine.get_efficiency_from_load_percentage(load)
        idx_motor = power_shaft > 0
        idx_generator = np.bitwise_not(idx_motor)
        power_electric[idx_motor] = power_shaft[idx_motor] / efficiency[idx_motor]
        power_shaft[idx_generator] = power_electric[idx_generator] / efficiency[idx_generator]
        # Test for power input from the shaft side
        power_electric_pred, load_pred = electric_machine.get_electric_power_load_from_shaft_power(power_shaft)
        self.assertAlmostEqual((np.abs(power_electric_pred - power_electric)).sum() / number_of_point_to_test, 0, 1)
        self.assertAlmostEqual((np.abs(load - load_pred)).sum() / number_of_point_to_test, 0, 2)
        # Test for power input from the electric side
        power_shaft_pred, load = electric_machine.get_shaft_power_load_from_electric_power(power_electric, True)
        self.assertAlmostEqual((np.abs(power_shaft - power_shaft_pred)).sum() / number_of_point_to_test, 0, 4)
        self.assertAlmostEqual((np.abs(load - load_pred)).sum() / number_of_point_to_test, 0, 2)

    def test_electric_component_efficiency_interpolation_with_a_single_point_input(self):
        efficiency = .45
        generator = ElectricComponent(
            name='generator', type_=TypeComponent.GENERATOR, rated_power=100, rated_speed=100,
            eff_curve=np.array([efficiency])
        )
        self.assertAlmostEqual(generator.get_efficiency_from_load_percentage(.45), efficiency)

    def test_electric_component_with_file_input(self):
        name = 'generator 1'
        filename = 'info.csv'
        columns = ['Switchboard No', 'Rated Power', 'Rated Speed']
        df = create_dataframe_save_and_return(name, filename, columns)
        efficiency_function, efficiency = get_efficiency_curve_from_dataframe(df, 'Efficiency')
        #: Create an engine object and test_for_fuel_calculation_for_machinery_system
        gen = ElectricComponent(type_=TypeComponent.GENERATOR, power_type=TypePower.POWER_SOURCE, file_name=filename)
        load_point = np.random.rand()
        self.assertEqual(gen.name, name)
        self.assertAlmostEqual(gen.rated_speed, df['Rated Speed'].values[0])
        self.assertAlmostEqual(gen.rated_power, df['Rated Power'].values[0])
        self.assertAlmostEqual((gen._efficiency_points - efficiency).sum(), 0)
        self.assertAlmostEqual(gen.get_efficiency_from_load_percentage(load_point),
                               np.clip(efficiency_function(load_point), .01, 1))
        os.unlink(filename)

    def test_serial_system(self):
        gearbox = BasicComponent(
            type_=TypeComponent.GEARBOX, name='gearbox',
            power_type=TypePower.POWER_TRANSMISSION,
            rated_power=3000, rated_speed=150, eff_curve=np.array([98.])
        )
        synch_mach = ElectricMachine(
            type_=TypeComponent.SYNCHRONOUS_MACHINE, name='synchronous machine', rated_power=3000,
            rated_speed=150, eff_curve=self.electric_machine_eff_curve
        )
        rectifier = ElectricComponent(type_=TypeComponent.RECTIFIER, name='rectifier', rated_power=3000,
                                      eff_curve=np.array([99.5]))
        inverter = ElectricComponent(type_=TypeComponent.INVERTER, name='inverter', rated_power=3000,
                                     eff_curve=self.converter_eff)
        transformer = ElectricComponent(type_=TypeComponent.TRANSFORMER, name='transformer', rated_power=3000,
                                        eff_curve=np.array([99]))

        components = [gearbox, synch_mach, rectifier, inverter, transformer]
        pti_pto = SerialSystem(
            TypeComponent.PTI_PTO, TypePower.PTI_PTO, 'PTIPTO 1',
            components, rated_power=transformer.rated_power,
            rated_speed=synch_mach.rated_speed
        )
        load_perc = .50  # np.random.rand() * 100
        efficiency = 1
        for component in components:
            efficiency *= component.get_efficiency_from_load_percentage(load_perc)
        self.assertAlmostEqual(pti_pto.get_efficiency_from_load_percentage(load_perc), efficiency, places=-1)
        return pti_pto

    def test_pti_pto(self):

        #: Get a generic pti_pto instance from SerialSystem testing
        pti_pto_serial = self.test_serial_system()

        #: Create a PTIPTO instance
        switchboard_id = 1
        shaft_line_id = 1
        pti_pto = PTIPTO(
            pti_pto_serial.name, pti_pto_serial.components,
            switchboard_id, pti_pto_serial.rated_power, pti_pto_serial.rated_speed,
            shaft_line_id
        )
        self.assertEqual(shaft_line_id, pti_pto.shaft_line_id)

    def test_serial_system_electric(self):
        switchboard_no = 0
        power_type = TypePower.PTI_PTO
        PTIPTO = self.test_serial_system()
        PTIPTO_electric = SerialSystemElectric(
            PTIPTO.type, PTIPTO.name, power_type, PTIPTO.components, switchboard_no,
            PTIPTO.rated_power, PTIPTO.rated_speed
        )
        self.assertEqual(PTIPTO_electric.switchboard_id, switchboard_no)
        self.assertEqual(PTIPTO_electric.power_type, power_type)

    def test_main_engine_with_gear_box(self):
        engine = create_engine_component('main_engine 1', 1000, 1000)
        gearbox = BasicComponent(
            type_=TypeComponent.GEARBOX, name='gearbox',
            power_type=TypePower.POWER_TRANSMISSION,
            rated_power=engine.rated_power, rated_speed=engine.rated_speed,
            eff_curve=np.array([98])
        )
        main_engine_with_gearbox = MainEngineWithGearBoxForMechanicalPropulsion('main engine with GB', engine, gearbox)
        power_at_gearbox_out = np.random.rand(5) * gearbox.rated_power
        load = gearbox.get_load(power_at_gearbox_out)
        eff_gearbox = gearbox.get_efficiency_from_load_percentage(load)
        power_at_engine_shaft = power_at_gearbox_out / eff_gearbox
        fuel_cons, load_percentage, bsfc = engine.get_fuel_cons_load_bsfc_from_power_out_kw(power_at_engine_shaft)
        fuel_cons_comp, load_percentage_comp, bsfc_comp = \
            main_engine_with_gearbox.get_fuel_cons_load_bsfc_from_power_out_kw(power_at_gearbox_out)
        self.assertEqual((fuel_cons - fuel_cons_comp).sum(), 0)
        self.assertEqual((load_percentage - load_percentage_comp).sum(), 0)
        self.assertEqual((bsfc - bsfc_comp).sum(), 0)

    def test_genset(self):
        #: Create an engine component
        engine = create_engine_component('auxiliary engine 1', 1000, 1000)
        #: Create a generator component
        generator = ElectricMachine(
            type_=TypeComponent.GENERATOR, name='generator 1', rated_power=engine.rated_power * 0.9,
            rated_speed=engine.rated_speed,
            power_type=TypePower.POWER_SOURCE, switchboard_id=0, number_poles=4,
            eff_curve=self.electric_machine_eff_curve
        )
        rectifier = ElectricComponent(
            type_=TypeComponent.RECTIFIER, name='rectifier 1', rated_power=generator.rated_power,
            eff_curve=np.array([99])
        )
        genset_ac = Genset('genset 1', engine, generator)
        genset_dc = Genset('genset 1', engine, generator, rectifier)
        power_electric = np.random.rand(5) * genset_ac.rated_power
        load_at_genset = generator.get_load(power_electric)
        power_dc_at_generator = power_electric / rectifier.get_efficiency_from_load_percentage(load_at_genset)
        power_shaft_ac, load_perc = generator.get_shaft_power_load_from_electric_power(power_electric)
        power_shaft_dc, load_perc = generator.get_shaft_power_load_from_electric_power(power_dc_at_generator)
        fuel_cons, load_at_engine, bsfc_ac = engine.get_fuel_cons_load_bsfc_from_power_out_kw(power_shaft_ac)
        fuel_cons, load_at_engine, bsfc_dc = engine.get_fuel_cons_load_bsfc_from_power_out_kw(power_shaft_dc)
        fuel_cons, load_at_engine, bsfc_ac_comp, load_at_genset = \
            genset_ac.get_fuel_cons_load_bsfc_from_power_out_generator_kw(power_electric)
        fuel_cons, load_at_engine, bsfc_dc_comp, load_at_genset = \
            genset_dc.get_fuel_cons_load_bsfc_from_power_out_generator_kw(power_electric)
        self.assertAlmostEqual((bsfc_ac - bsfc_ac_comp).sum() / 5, 0, 1)
        self.assertAlmostEqual((bsfc_dc - bsfc_dc_comp).sum() / 5, 0, 0)

    def test_switchboard(self):
        number_of_components = 20
        no_points_to_test = 10000
        power_avail_total = 3000

        #: Distribute number of components by types
        number_of_components_list = get_list_random_distribution_numbers_for_total_number(4, number_of_components)
        switchboard = create_switchboard_with_components(
            1, power_avail_total,
            no_power_sources=number_of_components_list[0],
            no_power_consumer=number_of_components_list[1],
            no_pti_ptos=number_of_components_list[2],
            no_energy_storage=number_of_components_list[3],
        )
        power_types = [component.power_type for component in switchboard.components]

        # Test initialization
        self.assertEqual(power_types.count(TypePower.POWER_SOURCE), switchboard.no_power_sources)
        self.assertEqual(power_types.count(TypePower.POWER_CONSUMER), switchboard.no_consumers)
        self.assertEqual(power_types.count(TypePower.ENERGY_STORAGE), switchboard.no_energy_storage)
        self.assertEqual(power_types.count(TypePower.PTI_PTO), switchboard.no_pti_pto)

        # Test setting and getting the status of the power source
        status_power_source = switchboard.get_status_component_by_power_type(TypePower.POWER_SOURCE)
        self.assertEqual(
            np.array(status_power_source).all(), np.ones([switchboard.no_power_sources, 1]).astype(bool).all()
        )
        status_new_power_source = np.round(np.random.rand(no_points_to_test, switchboard.no_power_sources)).astype(bool)
        index_all_power_source_off = np.bitwise_not(status_new_power_source).all(axis=1) == True
        status_new_power_source[index_all_power_source_off, 0] = True  # Make sure at least one power source is on
        switchboard.set_status_components_by_power_type(type_=TypePower.POWER_SOURCE, status=status_new_power_source)
        status_power_source = switchboard.get_status_component_by_power_type(TypePower.POWER_SOURCE)
        status_new_pti_pto = np.round(np.random.rand(no_points_to_test, switchboard.no_pti_pto)).astype(bool)
        switchboard.set_status_components_by_power_type(type_=TypePower.PTI_PTO, status=status_new_pti_pto)
        status_pti_pto = switchboard.get_status_component_by_power_type(TypePower.PTI_PTO)
        status_new_energy_storage = \
            np.round(np.random.rand(no_points_to_test, switchboard.no_energy_storage)).astype(bool)
        switchboard.set_status_components_by_power_type(
            type_=TypePower.ENERGY_STORAGE, status=status_new_energy_storage
        )
        status_energy_storage = switchboard.get_status_component_by_power_type(TypePower.ENERGY_STORAGE)
        self.assertEqual(np.equal(np.array(status_power_source).transpose(), status_new_power_source).all(), True)
        self.assertEqual(np.equal(np.array(status_pti_pto).transpose(), status_new_pti_pto).all(), True)
        self.assertEqual(np.equal(np.array(status_energy_storage).transpose(), status_new_energy_storage).all(), True)

        # Test setting and getting the load sharing status of the power source
        load_sharing_status = switchboard.get_load_sharing_mode_components_by_power_type(TypePower.POWER_SOURCE)
        self.assertEqual(np.abs(np.array(load_sharing_status)).sum(), 0)
        load_sharing_mode_new = np.random.rand(no_points_to_test, switchboard.no_power_sources)
        load_sharing_mode_new[load_sharing_mode_new < 0.7] = 0
        switchboard.set_load_sharing_mode_components_by_power_type(TypePower.POWER_SOURCE, load_sharing_mode_new)
        load_sharing_status = switchboard.get_load_sharing_mode_components_by_power_type(TypePower.POWER_SOURCE)
        self.assertEqual(np.equal(np.array(load_sharing_status).transpose(), load_sharing_mode_new).all(), True)
        load_sharing_mode_new_pti_pto = np.random.rand(no_points_to_test, switchboard.no_pti_pto)
        load_sharing_mode_new_pti_pto[load_sharing_mode_new_pti_pto < 0.1] = 0
        load_sharing_mode_new_pti_pto[load_sharing_mode_new_pti_pto >= 0.1] = 1
        switchboard.set_load_sharing_mode_components_by_power_type(TypePower.PTI_PTO, load_sharing_mode_new_pti_pto)
        load_sharing_status = switchboard.get_load_sharing_mode_components_by_power_type(TypePower.PTI_PTO)
        self.assertEqual(np.equal(np.array(load_sharing_status).transpose(), load_sharing_mode_new_pti_pto).all(), True)
        load_sharing_mode_new_energy_storage = np.random.rand(no_points_to_test, switchboard.no_energy_storage)
        load_sharing_mode_new_energy_storage[load_sharing_mode_new_energy_storage < 0.1] = 0
        load_sharing_mode_new_energy_storage[load_sharing_mode_new_energy_storage >= 0.1] = 1
        switchboard.set_load_sharing_mode_components_by_power_type(
            TypePower.ENERGY_STORAGE, load_sharing_mode_new_energy_storage
        )
        load_sharing_status = switchboard.get_load_sharing_mode_components_by_power_type(TypePower.ENERGY_STORAGE)
        self.assertEqual(
            np.equal(np.array(load_sharing_status).transpose(), load_sharing_mode_new_energy_storage).all(), True
        )

        # Test getting the available rated power
        rated_power_list = []
        for component in switchboard.components:
            if component.power_type == TypePower.POWER_SOURCE:
                rated_power_list.append(component.rated_power * component.status)
        rated_power_list_from_class = switchboard.get_power_avail_component_by_power_type(TypePower.POWER_SOURCE)
        rated_power_array = np.array(rated_power_list).transpose()
        rated_power_array_from_class = np.array(rated_power_list_from_class).transpose()
        self.assertEqual(np.sum(np.abs(rated_power_array - rated_power_array_from_class)), 0)

        # Test setting power input of the component from the given output.
        component: Union[ElectricComponent or Genset] = random.choice(switchboard.components)
        while type(component) in [Genset, FuelCellSystem]:
            component = random.choice(switchboard.components)
        component: Union[ElectricComponent or Genset] = random.choice(switchboard.components)
        power_output_ref = np.random.rand(no_points_to_test) * component.rated_power
        power_input_ref, load = component.get_power_input_from_bidirectional_output(power_output_ref)
        switchboard.set_power_load_component_from_power_output_by_type_and_name(
            component.name, component.power_type, power_output_ref
        )
        self.assertTrue(np.equal(power_input_ref, component.power_input).all())

        # Test getting the switchboard load (sum of the power input of the power consumers)
        load_perc_symmetric_loaded_power_source, sum_power_input_for_power_consumer, sum_power_input_for_pti_pto, \
        sum_power_input_for_energy_storage = \
            set_random_power_input_consumer_pti_pto_energy_storage(no_points_to_test, switchboard)
        sum_power_input = [
            sum_power_input_for_power_consumer, sum_power_input_for_pti_pto, sum_power_input_for_energy_storage
        ]
        for i, type_ in enumerate([TypePower.POWER_CONSUMER, TypePower.PTI_PTO, TypePower.ENERGY_STORAGE]):
            self.assertAlmostEqual(
                np.sum(switchboard.get_sum_power_input_by_power_type(type_=type_)),
                np.sum(sum_power_input[i])
            )

        #: Test power source load calculation
        load_perc_symmetric_loaded_power_source_comp = switchboard.get_sum_load_kw_sources_symmetric() / \
                                                       switchboard.get_sum_power_avail_for_power_sources_symmetric()
        load_perc_symmetric_loaded_power_source[np.isinf(load_perc_symmetric_loaded_power_source)] = 0
        load_perc_symmetric_loaded_power_source_comp[np.isinf(load_perc_symmetric_loaded_power_source_comp)] = 0
        load_perc_symmetric_loaded_power_source[np.isnan(load_perc_symmetric_loaded_power_source)] = 0
        load_perc_symmetric_loaded_power_source_comp[np.isnan(load_perc_symmetric_loaded_power_source_comp)] = 0
        self.assertTrue(
            np.allclose(
                load_perc_symmetric_loaded_power_source_comp,
                load_perc_symmetric_loaded_power_source
            )
        )

        #: Test setting the power output of PTI/PTO / battery
        time_step = 1.0
        switchboard.set_power_out_power_sources(load_perc_symmetric_loaded_power_source_comp)
        result = switchboard.get_fuel_energy_consumption_running_time(time_step)
        for power_source in switchboard.component_by_power_type[TypePower.POWER_SOURCE.value]:
            index = power_source.load_sharing_mode > 0
            power_output = power_source.rated_power * load_perc_symmetric_loaded_power_source_comp
            power_output *= power_source.status
            power_output[index] = power_source.rated_power * power_source.load_sharing_mode[index]
            power_output[index] = power_output[index] * power_source.status[index]
            self.assertTrue(
                np.equal(
                    np.round(power_output, 3),
                    np.round(power_source.power_output, 3)
                ).all()
            )

    def test_shaft_line(self):

        time_step = 1
        number_test_points = 100
        number_main_engines = random.randint(1, 4)
        rated_speed = 700

        main_engines = []
        total_rated_power_main_engine = 0

        #: Create main engine components with gear boxes
        for i in range(number_main_engines):
            #: Maximum random rated power (1500 ~ 3000 kW)
            rated_power_max = 3000

            engine_id = i + 1
            main_engine = create_engine_component(
                'main engine %i' % engine_id, rated_power_max, rated_speed,
            )
            rated_power = main_engine.rated_power

            #: Get total rated power of main engines
            total_rated_power_main_engine += rated_power

            #: Create a gearbox instance
            gearbox = BasicComponent(
                type_=TypeComponent.GEARBOX, name='gearbox',
                power_type=TypePower.POWER_TRANSMISSION,
                rated_power=rated_power, rated_speed=150, eff_curve=np.array([98.])
            )

            #: Create a main engine with a gear box instance and collect it in the list
            main_engines.append(
                MainEngineWithGearBoxForMechanicalPropulsion(
                    'main engine %i' % engine_id,
                    main_engine, gearbox, 1
                )
            )

        #: Create a pti/pto
        pti_pto = create_a_pti_pto('PTI/PTO', rated_power=1000)

        #: Create a propeller load
        rated_power_propeller = 0.5 * (random.random() + 1) * \
                                (total_rated_power_main_engine + pti_pto.rated_power)
        propeller_load = MechanicalPropulsionComponent(
            TypeComponent.PROPELLER_LOAD, TypePower.POWER_CONSUMER,
            'propeller 1', rated_power_propeller, np.array([1]),
            rated_speed=150, shaft_line_id=1
        )

        #: Create a shaft line component
        shaft_line = ShaftLine('shaft line 1', 1, main_engines + [pti_pto, propeller_load])

        #: Test pure mechanical propulsion mode
        while True:
            #: Set the power input for the propeller load
            propeller_load.power_input = np.random.rand(number_test_points) * \
                                         (propeller_load.rated_power - pti_pto.rated_power)

            #: Set the main engine status so that total available power is greater than
            #: The load.
            status = np.random.rand(number_test_points, len(main_engines)) > 0.5
            total_power_available = 0
            for _ in range(2):
                total_power_available = 0
                for i, main_engine in enumerate(main_engines):
                    total_power_available += status[:, i] * main_engine.rated_power
                    main_engine.status = status[:, i]
                index = total_power_available < propeller_load.power_input
                if index.any():
                    status[index, :] = True
                else:
                    break
            if (total_power_available > propeller_load.power_input).all():
                break

        #: Get total power available and total running hours for reference
        total_power_available = 0
        total_running_hours_ref = 0
        for main_engine in main_engines:
            total_power_available += main_engine.rated_power * main_engine.status
            total_running_hours_ref += main_engine.status
        total_running_hours_ref = total_running_hours_ref.sum() * time_step / 3600
        total_load_percentage_ref = propeller_load.power_input / total_power_available

        #: Calculate the reference fuel consumption
        fuel_consumption_rate_ref = 0
        for main_engine in main_engines:
            fuel_consumption_rate_temp, _, _ = main_engine.get_fuel_cons_load_bsfc_from_power_out_kw(
                main_engine.rated_power * total_load_percentage_ref * main_engine.status
            )
            fuel_consumption_rate_ref += fuel_consumption_rate_temp
        fuel_consumption_ref = simps(fuel_consumption_rate_ref) * time_step

        #: Set the PTI/PTO power 0
        pti_pto.power_input = pti_pto.set_power_output_from_input(np.zeros(number_test_points))
        pti_pto.full_pti_mode = np.zeros(number_test_points).astype(bool)
        #: Do the power balance calculation
        shaft_line.do_power_balance()

        #: Calculate fuel calculation
        result = shaft_line.get_fuel_calculation_running_hours(time_step)

        #: Check the result
        self.assertAlmostEqual(result.running_hours_main_engines_hr, total_running_hours_ref)
        self.assertAlmostEqual(result.fuel_consumption_total_kg, fuel_consumption_ref)

        #: Test the hybrid propulsion
        while True:
            #: Set the power input for the propeller load
            propeller_load.power_input = np.random.rand(number_test_points) * propeller_load.rated_power

            #: Set the main engine status so that total available power is greater than the load.
            status = np.random.rand(number_test_points, len(main_engines)) > 0.5
            total_power_available = 0
            for _ in range(2):
                total_power_available = 0
                for i, main_engine in enumerate(main_engines):
                    total_power_available += status[:, i] * main_engine.rated_power
                    main_engine.status = status[:, i]
                total_power_available += pti_pto.rated_power
                index = total_power_available < propeller_load.power_input
                if index.any():
                    status[index, :] = True
                else:
                    break
            if (total_power_available > propeller_load.power_input).all():
                break
        total_power_available_main_engines = total_power_available - pti_pto.rated_power

        #: Generate power output for PTI/PTO. Negative means PTO, positive means PTI
        power_output_pti_pto = (np.random.rand(100) * 2 - 1) * pti_pto.rated_power

        #: Check power balance
        max_power_output_pti_pto = propeller_load.power_input
        power_output_pti_pto = np.minimum(power_output_pti_pto, max_power_output_pti_pto)
        min_power_output_pti_pto = -(total_power_available_main_engines - propeller_load.power_input)
        power_output_pti_pto = np.maximum(power_output_pti_pto, min_power_output_pti_pto)
        pti_pto.full_pti_mode = power_output_pti_pto == max_power_output_pti_pto

        #: Get the reference value for running hours and fuel consumption
        total_power_output_main_engines = propeller_load.power_input - power_output_pti_pto
        status = total_power_output_main_engines > 0
        total_load_percentage_ref = np.zeros(number_test_points)
        total_load_percentage_ref[status] = \
            total_power_output_main_engines[status] / total_power_available_main_engines[status]
        total_running_hours_ref = 0
        fuel_consumption_ref = 0
        for engine in main_engines:
            engine.status[np.bitwise_not(status)] = False
            engine.power_output = total_load_percentage_ref * engine.rated_power * engine.status
            fuel_consumption_rate_temp, _, _ = engine.get_fuel_cons_load_bsfc_from_power_out_kw()
            fuel_consumption_ref += simps(fuel_consumption_rate_temp) * time_step
            total_running_hours_ref += engine.status.sum() * time_step / 3600

        #: Set the PTI/PTO power
        pti_pto.set_power_input_from_output(power_output_pti_pto)

        #: Calculate PTI/PTO running hours
        total_running_hours_ref += (pti_pto.power_output != 0).sum() * time_step / 3600

        #: Do the power balance calculation
        total_load_percentage = shaft_line.do_power_balance()

        #: Get fuel calculation
        result = shaft_line.get_fuel_calculation_running_hours(time_step)
        self.assertAlmostEqual(result.fuel_consumption_total_kg, fuel_consumption_ref)
        self.assertAlmostEqual(result.running_hours_main_engines_hr, total_running_hours_ref)

        print(result)
